﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiDroppoint : UserControl
    {
        public UiDroppoint()
        {
            InitializeComponent();
            string query = "select top 1 id_droppoint from ms_droppoint order by id_droppoint desc";
            txtIddroppoint.Text = autogenerateID("DP", query);
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (txtIddroppoint.Text == "" || cmbKota.Text == "" || txtNama.Text == "")
            {
                MessageBox.Show("Data harus lengkap ");
            }
            else
            {
                try
                {
                    string koneksiString = "integrated security = true; data source = DESKTOP-QVO3FSO\\SQLEXPRESS; initial catalog = TravelAR";
                    SqlConnection koneksi = new SqlConnection(koneksiString);
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = koneksi;
                    cmd.CommandText = "sp_inputdroppoint";
                    //mengatur tipe command yang akan digunakan
                    cmd.CommandType = CommandType.StoredProcedure;

                    //parameter yang akan dikirimkan ke sp di basis data
                    cmd.Parameters.AddWithValue("@id_dropPoint", txtIddroppoint.Text);
                    cmd.Parameters.AddWithValue("@kota", cmbKota.Text);
                    cmd.Parameters.AddWithValue("@nama", txtNama.Text);

                    koneksi.Open();
                    int result = Convert.ToInt32(cmd.ExecuteNonQuery());
                    koneksi.Close();

                    //cek apakah ada data yang ditambahkan
                    if (result != 0)
                    {
                        MessageBox.Show("Input data berhasil");
                    }
                    else
                    {
                        MessageBox.Show("Failed");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message);
                }
            }
        }
        private void Tampilcmbkota()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT asal FROM tb_tempat", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKota.Items.Clear();
            foreach (DataRow ROW in dt.Rows)
            {
                cmbKota.Items.Add(ROW["asal"].ToString());
            }
        }

        private void UiDroppoint_Load(object sender, EventArgs e)
        {
            Tampilcmbkota();
            Datagrid();
            droppointcariupdate1.Hide();
            btnKembali.Hide();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatdroppoint", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            txtIddroppoint.Text = "";
            cmbKota.Text = "";
            txtNama.Text = "";
            string query = "select top 1 id_droppoint from ms_droppoint order by id_droppoint desc";
            txtIddroppoint.Text = autogenerateID("DP", query);

        }

        private void btnHapus2_Click(object sender, EventArgs e)
        {
            droppointcariupdate1.Show();
            btnKembali.Show();
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            droppointcariupdate1.Hide();
            btnKembali.Hide();
        }
    }
}
