﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiKendaraan : UserControl
    {
        public UiKendaraan()
        {
            InitializeComponent();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
            SqlConnection connection = new SqlConnection(connectionstring);

            SqlCommand insert = new SqlCommand("sp_inputkendaraan", connection);
            insert.CommandType = CommandType.StoredProcedure;

            insert.Parameters.AddWithValue("id_kendaraan", txtIdKendaraan.Text);
            insert.Parameters.AddWithValue("jenis", cmbJenis.Text);
            insert.Parameters.AddWithValue("kapasitas", cmbKapasitas.Text);
            insert.Parameters.AddWithValue("kota_asal", cmbKotaasal.Text);
            insert.Parameters.AddWithValue("kota_tujuan", cmbKotatujuan.Text);
            insert.Parameters.AddWithValue("harga", txtHarga.Text);

            try
            {
                connection.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data Belum Tersimpan " + ex.Message);

            }
        }
    }
}
