﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiJadwal : UserControl
    {
        public UiJadwal()
        {
            InitializeComponent();
            string query = "select top 1 id from tb_tempat order by id desc";
            textBox1.Text = autogenerateID("", query);
            textBox1.Hide();
            label7.Hide();
            Tampilcmbid();
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void UiJadwal_Load(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnSimpan2_Click(object sender, EventArgs e)
        {
            if (txtAsal.Text == "" || txtTujuan.Text == "")
            {
                MessageBox.Show("Data harus lengkap ");
            }
            else
            {
                try
                {
                    string koneksiString = "integrated security = true; data source = DESKTOP-QVO3FSO\\SQLEXPRESS; initial catalog = TravelAR";
                    SqlConnection koneksi = new SqlConnection(koneksiString);
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = koneksi;
                    cmd.CommandText = "sp_inputtempat";
                    //mengatur tipe command yang akan digunakan
                    cmd.CommandType = CommandType.StoredProcedure;

                    //parameter yang akan dikirimkan ke sp di basis data
                    cmd.Parameters.AddWithValue("@id", textBox1.Text);
                    cmd.Parameters.AddWithValue("@asal", txtAsal.Text);
                    cmd.Parameters.AddWithValue("@tujuan", txtTujuan.Text);

                    koneksi.Open();
                    int result = Convert.ToInt32(cmd.ExecuteNonQuery());
                    koneksi.Close();

                    //cek apakah ada data yang ditambahkan
                    if (result != 0)
                    {
                        MessageBox.Show("Input data berhasil");
                        Reset();
                        Datagrid();

                    }
                    else
                    {
                        MessageBox.Show("Failed");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message);
                }
            }
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatTEMPAT", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView2.DataSource = dt;
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            //textBox1.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtAsal.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtTujuan.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
        }

        private void btnHapus2_Click(object sender, EventArgs e)
        {
            if (txtAsal.Text == "" || txtTujuan.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletetempat", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id", textBox1.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    Reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }
        private void Reset()
        {
            txtAsal.Text = "";
            txtTujuan.Text = "";
            textBox1.Text = "";
        }
        private void Tampilcmbid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT id_kendaraan FROM ms_kendaraan", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbIdbus.Items.Clear();
            foreach (DataRow ROW in dt.Rows)
            {
                cmbIdbus.Items.Add(ROW["id_kendaraan"].ToString());
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (cmbIdbus.Text == "")
            {
                MessageBox.Show("Data harus lengkap ");
            }
            else
            {
                try
                {
                    string koneksiString = "integrated security = true; data source = DESKTOP-QVO3FSO\\SQLEXPRESS; initial catalog = TravelAR";
                    SqlConnection koneksi = new SqlConnection(koneksiString);
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = koneksi;
                    cmd.CommandText = "sp_inputtempat";
                    //mengatur tipe command yang akan digunakan
                    cmd.CommandType = CommandType.StoredProcedure;

                    //parameter yang akan dikirimkan ke sp di basis data
                    cmd.Parameters.AddWithValue("@id", textBox1.Text);
                    cmd.Parameters.AddWithValue("@asal", txtAsal.Text);
                    cmd.Parameters.AddWithValue("@tujuan", txtTujuan.Text);

                    koneksi.Open();
                    int result = Convert.ToInt32(cmd.ExecuteNonQuery());
                    koneksi.Close();

                    //cek apakah ada data yang ditambahkan
                    if (result != 0)
                    {
                        MessageBox.Show("Input data berhasil");
                        Reset();
                        Datagrid();

                    }
                    else
                    {
                        MessageBox.Show("Failed");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message);
                }
            }
        }
    }
}
