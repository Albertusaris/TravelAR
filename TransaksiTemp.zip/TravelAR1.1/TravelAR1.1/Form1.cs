﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelAR1._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Form1 form = new Form1();
            //form.SetDesktopLocation(500, 500);
        }

       
        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool IsAuthentic(string username, string password)
        {
            bool valid;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True";
            {
                SqlCommand cmd = new SqlCommand("sp_login", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                con.Open();
                int status;
                status = Convert.ToInt32(cmd.ExecuteScalar());
                if (status == 1)
                {
                    valid = true;
                }
                else
                {
                    valid = false;
                }
                con.Close();
                return valid;
            }
        }
        private string[] getuserdata(string username, string password)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True";
            {
                SqlCommand cmd = new SqlCommand("sp_getuserdata", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                string[] employeedata = new string[9];
                while (dr.Read())
                {
                    employeedata[0] = dr["id_karyawan"].ToString();
                    employeedata[1] = dr["nama"].ToString();
                    employeedata[2] = dr["nik"].ToString();
                    employeedata[3] = dr["email"].ToString();
                    employeedata[4] = dr["no_telp"].ToString();
                    employeedata[5] = dr["username"].ToString();
                    employeedata[6] = dr["password"].ToString();
                    employeedata[7] = dr["jabatan"].ToString();
                    employeedata[8] = dr["status"].ToString();

                }
                con.Close();
                return employeedata;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //btnLogin2.Hide();
            uiTransBus1.Show();
        }

        private void uiHome1_Load(object sender, EventArgs e)
        {

        }

        private void PanelKiri_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            //uiLogin1.Show();
            
            //uiHome1.Show();
            //uiloginadm1.Hide();
            //uilogincs1.Hide();
            //uiloginmanager1.Hide();
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            //uiHome1.Hide();
            //uiloginadm1.Show();
            //uilogincs1.Hide();
            //uiloginmanager1.Hide();
        }

        private void btnCs_Click(object sender, EventArgs e)
        {
            //uiHome1.Hide();
            //uiloginadm1.Hide();
            //uilogincs1.Show();
            //uiloginmanager1.Hide();
        }

        private void btnManager_Click(object sender, EventArgs e)
        {
            //uiHome1.Hide();
            //uiloginadm1.Hide();
            //uilogincs1.Hide();
            //uiloginmanager1.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string[] employeedata = new string[9];
            if (IsAuthentic(txtUsername.Text, txtPassword.Text))
            {
                employeedata = getuserdata(txtUsername.Text, txtPassword.Text);
                MessageBox.Show("Nama : " + employeedata[1] + "\nJabatan : " + employeedata[7]);
                if (employeedata[7].Equals("Admin"))
                {
                    MessageBox.Show("Berhasil Login Sebagai Admin");
                    this.Hide();
                    UihomeAdmin admin = new UihomeAdmin();
                    admin.Show();
                    

                }
                else if (employeedata[7].Equals("Customer Service"))
                {
                    MessageBox.Show("Berhasil Login Sebagai Customer Service");
                }
                else
                {
                    MessageBox.Show("Berhasil Login Sebagai Manager");
                }



            }
            else
            {
                MessageBox.Show("Username atau Password Anda Salah");
            }
        }

        private void btnLogin2_Click(object sender, EventArgs e)
        {
            btnLogin.Hide();

        }

        private void btn_Click(object sender, EventArgs e)
        {
            btnLogin.Hide();
            //btnLogin2.Show();
        }

        private void PanelAtas_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
