﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class hotelcariupdate : UserControl
    {
        public hotelcariupdate()
        {
            InitializeComponent();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihathotel", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }
        private void hotelcariupdate_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtIdhotel.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtKota.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtnama.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtTipekamar.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtKamar.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtHarga.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (txtIdhotel.Text == "" || txtKota.Text == "" || txtnama.Text == "" || txtTipekamar.Text == "" || txtHarga.Text == "" || txtKamar.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatehotel", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@jumlah_kamar", txtKamar.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@harga", txtHarga.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@id_hotel", txtIdhotel.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil DiUpdate!");
            }
                
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtIdhotel.Text == "" || txtKota.Text == "" || txtnama.Text == "" || txtTipekamar.Text == "" || txtHarga.Text == "" || txtKamar.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletehotel", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id_hotel", txtIdhotel.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    Reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
                
        }
        private void Reset()
        {
            txtIdhotel.Text = "";
            txtKota.Text = "";
            txtnama.Text = "";
            txtTipekamar.Text = "";
            txtKamar.Text = "";
            txtHarga.Text = "";
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void txtKamar_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtHarga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
