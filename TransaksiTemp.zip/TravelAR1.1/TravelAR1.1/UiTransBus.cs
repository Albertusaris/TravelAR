﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiTransBus : UserControl
    {
        public UiTransBus()
        {
            InitializeComponent();
            Tampilcmbkota();
            string query = "select top 1 id_transaksi from ms_trans_bus order by id_transaksi desc";
            txtId.Text = autogenerateID("TS", query);
            txtId.Hide();
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }
        private void Tampilcmbkota()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT asal FROM tb_tempat", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKotaAsal.Items.Clear();
            foreach (DataRow ROW in dt.Rows)
            {
                cmbKotaAsal.Items.Add(ROW["asal"].ToString());
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if(txtNama.Text==""||cmbKotaAsal.Text=="" || cmbKotaTujuan.Text=="" )
            {
                MessageBox.Show("Data Harus Diisi");
            }
            else
            {
                
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand mycmd = new SqlCommand("sp_getDataBus", connection);
                    mycmd.CommandType = CommandType.StoredProcedure;
                    mycmd.Parameters.AddWithValue("@kota_asal", cmbKotaAsal.Text);
                    mycmd.Parameters.AddWithValue("@kota_tujuan", cmbKotaTujuan.Text);
                    mycmd.Parameters.AddWithValue("@tanggal", dtTanggal.Value);
                    DataTable dt = new DataTable();
                    dt.Load(mycmd.ExecuteReader());
                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["jenis"].HeaderText = "Jenis";
                    dataGridView1.Columns["kapasitas"].HeaderText = "Kapasitas";
                    dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
                    dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
                    dataGridView1.Columns["droppoint"].HeaderText = "Drop Point";
                    dataGridView1.Columns["harga"].HeaderText = "Harga";
                    dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
                    dataGridView1.Columns["jam"].HeaderText = "Jam";
                    dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Data Tidak Ditemukan" + Ex);
                }
            }
           
           
        }

        private void cmbKotaAsal_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT tujuan FROM tb_tempat WHERE asal = '" + cmbKotaAsal.Text + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKotaTujuan.Items.Clear();
            foreach (DataRow AB in dt.Rows)
            {
                cmbKotaTujuan.Items.Add(AB["tujuan"].ToString());
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtJenis.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtDroppoint.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtNoplat.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtHarga.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtJam.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbKotaAsal_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT tujuan FROM tb_tempat WHERE asal = '" + cmbKotaAsal.Text + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKotaTujuan.Items.Clear();
            foreach (DataRow AB in dt.Rows)
            {
                cmbKotaTujuan.Items.Add(AB["tujuan"].ToString());
            }
        }

        private void btnSimpan_Click_1(object sender, EventArgs e)
        {
            if (txtNama.Text == "" || cmbKotaAsal.Text == "" || cmbKotaTujuan.Text == "")
            {
                MessageBox.Show("Data Harus Diisi");
            }
            else
            {

                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand mycmd = new SqlCommand("sp_getDataBus", connection);
                    mycmd.CommandType = CommandType.StoredProcedure;
                    mycmd.Parameters.AddWithValue("@kota_asal", cmbKotaAsal.Text);
                    mycmd.Parameters.AddWithValue("@kota_tujuan", cmbKotaTujuan.Text);
                    mycmd.Parameters.AddWithValue("@tanggal", dtTanggal.Value);
                    DataTable dt = new DataTable();
                    dt.Load(mycmd.ExecuteReader());
                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["jenis"].HeaderText = "Jenis";
                    dataGridView1.Columns["kapasitas"].HeaderText = "Kursi Tersisa";
                    dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
                    dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
                    dataGridView1.Columns["droppoint"].HeaderText = "Drop Point";
                    dataGridView1.Columns["harga"].HeaderText = "Harga";
                    dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
                    dataGridView1.Columns["jam"].HeaderText = "Jam";
                    dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
                    dataGridView1.Columns[6].DefaultCellStyle.Format = "MM/dd/yyyy";
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Data Tidak Ditemukan" + Ex);
                }
            }
        }

        private void UiTransBus_Load(object sender, EventArgs e)
        {
            //if(txtNoplat.Text=="")
            //{
            //    btnPesan.Enabled = false;
            //}
            //else
            //{
            //    btnPesan.Enabled = true;
            //}

        }

        private void cmbPenumpang_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                txtTotal.Text = (float.Parse(txtHarga.Text) * float.Parse(cmbPenumpang.Text)).ToString();
            }
            catch(Exception Ex)
            {
                MessageBox.Show("Error" + Ex);
            }
        }

        private void dtTanggal_ValueChanged(object sender, EventArgs e)
        {
            txtJenis.Text = "";
            txtDroppoint.Text = "";
            txtNoplat.Text = "";
            txtHarga.Text = "";
            txtTotal.Text = "";
            txtJam.Text = "";
        }

        private void btnPesan_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand insert = new SqlCommand("sp_inputtransbus", connection);
            insert.CommandType = CommandType.StoredProcedure;

            insert.Parameters.AddWithValue("id_transaksi", txtId.Text);
            insert.Parameters.AddWithValue("nama", txtNama.Text);
            insert.Parameters.AddWithValue("kota_asal", cmbKotaAsal.Text);
            insert.Parameters.AddWithValue("kota_tujuan", cmbKotaTujuan.Text);
            insert.Parameters.AddWithValue("tanggal", dtTanggal.Value.Date.ToShortDateString());
            insert.Parameters.AddWithValue("jenis", txtJenis.Text);
            insert.Parameters.AddWithValue("droppoint", txtDroppoint.Text);
            insert.Parameters.AddWithValue("no_plat", txtNoplat.Text);
            insert.Parameters.AddWithValue("jam", txtJam.Text);
            insert.Parameters.AddWithValue("harga", txtHarga.Text);
            insert.Parameters.AddWithValue("jml_penumpang", cmbPenumpang.Text);
            insert.Parameters.AddWithValue("total", txtTotal.Text);
            insert.Parameters.AddWithValue("status", txtStatus.Text);


            try
            {
                connection.Open();
                insert.ExecuteNonQuery();
                //Clear();
                //Datagrid();
                //Refresh();
                SqlCommand sqlcmd = new SqlCommand("sp_updatetransaksi", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@kapasitas", cmbPenumpang.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@no_plat", txtNoplat.Text.Trim());
                //sqlcmd.Parameters.AddWithValue("@id_kendaraan", txtIdKendaraan.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                reset();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Data Belum Tersimpan " + ex.Message);

            }
            //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            //connection.Open();
            //SqlCommand sqlcmd = new SqlCommand("sp_updatekendaraan1", connection);
            //sqlcmd.CommandType = CommandType.StoredProcedure;
            //sqlcmd.Parameters.AddWithValue("@harga", txtHarga.Text.Trim());
            //sqlcmd.Parameters.AddWithValue("@status", cmbStatus.Text.Trim());
            //sqlcmd.Parameters.AddWithValue("@id_kendaraan", txtIdKendaraan.Text.Trim());
            //sqlcmd.ExecuteNonQuery();
            //MessageBox.Show("Data Berhasil DiUpdate!");
        }
        private void reset()
        {
            txtJenis.Text = "";
            txtDroppoint.Text = "";
            txtNoplat.Text = "";
            txtHarga.Text = "";
            txtTotal.Text = "";
            txtJam.Text = "";
            txtNama.Text = "";
            cmbKotaAsal.Text = "";
            cmbKotaTujuan.Text = "";
            cmbPenumpang.Text = "";
        }
    }
}
