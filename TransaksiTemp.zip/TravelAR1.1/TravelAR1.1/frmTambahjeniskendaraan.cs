﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelAR1._1
{
    public partial class frmTambahjeniskendaraan : Form
    {
        public frmTambahjeniskendaraan()
        {
            InitializeComponent();
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
            SqlConnection connection = new SqlConnection(connectionstring);

            SqlCommand insert = new SqlCommand("sp_inputjenis", connection);
            insert.CommandType = CommandType.StoredProcedure;

            insert.Parameters.AddWithValue("jenis", txtJenis.Text);
            insert.Parameters.AddWithValue("kapasitas", txtKapasitas.Text);

            try
            {
                connection.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data Belum Tersimpan " + ex.Message);

            }
        }
        private void clear()
        {
            txtJenis.Text = "";
            txtKapasitas.Text = "";
        }

        private void btnBersihkan_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
