﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiLogin : UserControl
    {
        public UiLogin()
        {
            InitializeComponent();
        }

        private void UiLogin_Load(object sender, EventArgs e)
        {

        }
        private bool IsAuthentic(string username, string password)
        {
            bool valid;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True";
            {
                SqlCommand cmd = new SqlCommand("sp_login", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                con.Open();
                int status;
                status = Convert.ToInt32(cmd.ExecuteScalar());
                if(status == 1)
                {
                    valid = true;
                }
                else
                {
                    valid = false;
                }
                con.Close();
                return valid;
            }
        }
        private string[] getuserdata(string username, string password)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True";
            {
                SqlCommand cmd = new SqlCommand("sp_getuserdata", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                string[] employeedata = new string[9];
                while(dr.Read())
                {
                    employeedata[0] = dr["id_karyawan"].ToString();
                    employeedata[1] = dr["nama"].ToString();
                    employeedata[2] = dr["nik"].ToString();
                    employeedata[3] = dr["email"].ToString();
                    employeedata[4] = dr["no_telp"].ToString();
                    employeedata[5] = dr["username"].ToString();
                    employeedata[6] = dr["password"].ToString();
                    employeedata[7] = dr["jabatan"].ToString();
                    employeedata[8] = dr["status"].ToString();

                }
                con.Close();
                return employeedata;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string[] employeedata = new string[9];
            if(IsAuthentic(txtUsername.Text, txtPassword.Text))
            {
                employeedata = getuserdata(txtUsername.Text, txtPassword.Text);
                MessageBox.Show("Nama : " + employeedata[1] + "\nJabatan : " + employeedata[7]);
                if(employeedata[7].Equals("Admin"))
                {
                    MessageBox.Show("Berhasil Login Sebagai Admin");

                }
                else if(employeedata[7].Equals("Customer Service"))
                {
                    MessageBox.Show("CS");
                }
                else
                {
                    MessageBox.Show("Manager");
                }



            }
        }
    }
}
