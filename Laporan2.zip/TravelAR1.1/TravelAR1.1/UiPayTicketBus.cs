﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiPayTicketBus : UserControl
    {
        public UiPayTicketBus()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

        }

        private void UiPayTicketBus_Load(object sender, EventArgs e)
        {
            Datagrid();
            DatagridMember();
            //Cobaiin();
            txtResult.Hide();
        }
        private void Cobaiin()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlCommand Comm1 = new SqlCommand("SELECT COUNT total FROM ms_trans_bus WHERE status='Terbayar'",connection);
            connection.Open();
            //mycmd.ExecuteNonQuery();
            SqlDataReader DR1 = Comm1.ExecuteReader();
            if (DR1.Read())
            {
                txtId.Text = DR1.GetValue(0).ToString();
            }
            connection.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox6_OnValueChanged(object sender, EventArgs e)
        {

        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihattransaksibus", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["nama"].HeaderText = "Nama Pemesan";
            dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
            dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
            dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
            dataGridView1.Columns["jenis"].HeaderText = "Jenis Bus";
            dataGridView1.Columns["droppoint"].HeaderText = "DropPoint";
            dataGridView1.Columns["no_plat"].HeaderText = "NO Plat ";
            dataGridView1.Columns["jam"].HeaderText = "Jam";
            dataGridView1.Columns["harga"].HeaderText = "Harga";
            dataGridView1.Columns["jml_penumpang"].HeaderText = "Jumlah Penumpang";
            dataGridView1.Columns["total"].HeaderText = "Total Pembayaran";
            dataGridView1.Columns["status"].HeaderText = "Status";
            dataGridView1.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
            dataGridView1.Columns[9].DefaultCellStyle.Format = "Rp #,###.00";
            dataGridView1.Columns[11].DefaultCellStyle.Format = "Rp #,###.00";
        }
        public void DatagridMember()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmember", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView2.DataSource = dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtId.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtNama.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
           txtKotaAsal.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtKotaTujuan.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtTanggal.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtJenis.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtDroppoint.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtNoPlat.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtJam.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtJmlTiket.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
            txtTotal.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
            txtStatus.Text = dataGridView1.CurrentRow.Cells[12].Value.ToString();
            CekUang();
        }

        private void bunifuMaterialTextbox15_KeyPress(object sender, KeyPressEventArgs e)
        {
            //try
            //{
            //    txtKembalian.Text = (float.Parse(txtUang.Text) - float.Parse(txtTotal.Text)).ToString();
            //}
            //catch (Exception Ex)
            //{
            //    MessageBox.Show("Error" + Ex);
            //}
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtTotal_Load(object sender, EventArgs e)
        {
           
        }

        private void txtTotal_Leave(object sender, EventArgs e)
        {
            Double value;
            if (Double.TryParse(txtTotal.Text, out value))
                txtTotal.Text = String.Format(System.Globalization.CultureInfo.CurrentCulture, "{0:C2}", value);
            else
                txtTotal.Text = String.Empty;
        }

        private void txtUang_Leave(object sender, EventArgs e)
        {
                try
                {
                    txtKembalian.Text = (float.Parse(txtUang.Text) - float.Parse(txtTagihan.Text)).ToString();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error" + Ex);
                }
          
           
        }

        private void btnKonfirm_Click(object sender, EventArgs e)
        {
            if(txtNama.Text =="" || txtKotaTujuan.Text =="")
            {
                MessageBox.Show("Data Harus Diisi");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatestatusbus", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@status", "Terbayar");
                sqlcmd.Parameters.AddWithValue("@id_transaksi", txtId.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Pembayaran Berhasil");
                Datagrid();

                txtResult.Clear();
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "====================== TravelAR =======================\n";
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "\n";
                txtResult.Text += "Tanggal Pemesanan\t\t: " + txtTanggal.Text + "\n";
                txtResult.Text += "Nama Pemesan\t\t\t: " + txtNama.Text + "\n";
                txtResult.Text += "Jenis Kendaraan\t\t: " + txtJenis.Text + "\n";
                txtResult.Text += "No Plat\t\t\t\t: " + txtNoPlat.Text + "\n";
                txtResult.Text += "Jumlah Penumpang\t\t: " + txtJmlTiket.Text + "\n";
                txtResult.Text += "\n";
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "Total Pembayaran\t\t: " + txtTagihan.Text + "\n";
                txtResult.Text += "Uang Yang Dibayarkan\t\t: " + txtUang.Text + "\n";
                txtResult.Text += "Kembalian\t\t\t: " + txtKembalian.Text + "\n";
                txtResult.Text += "\n";
                txtResult.Text += "=====================================================\n";

                txtResult.Text += "============= Terimakasih Telah Bertransaksi ===============\n";

                txtNama.Text = "";
                txtJenis.Text = "";
                txtJam.Text = "";
                txtTagihan.Text = "";
                txtStatus.Text = "";
                txtTanggal.Text = "";
                txtTotal.Text = "";
                txtUang.Text = "";
                txtKotaAsal.Text = "";
                txtKotaTujuan.Text = "";
                txtJmlTiket.Text = "";
                txtDroppoint.Text = "";
                txtId.Text = "";
                txtKembalian.Text = "";


                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            }
         



        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtResult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txtIdMem.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtEmail.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
        }

        private void txtTagihan_Leave(object sender, EventArgs e)
        {
            try
            {
                txtTagihan.Text = (float.Parse(txtTotal.Text) * float.Parse("0.90")).ToString();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error" + Ex);
            }
        }
        private void CekUang()
        {
            if (txtIdMem.Text == "" || txtEmail.Text == "")
            {
                txtTagihan.Text = txtTotal.Text;
            }
            else
            {
                try
                {
                    txtTagihan.Text = (float.Parse(txtTotal.Text) * float.Parse("0.90")).ToString();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error" + Ex);
                }
            }

        }

        private void txtCariIdTrans_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNama_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtKotaTujuan_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtTanggal_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtDroppoint_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void txtNoPlat_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void txtJam_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void txtJmlTiket_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void txtTotal_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIdMember_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtCariMember_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtIdMem_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void txtTagihan_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void txtKembalian_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void txtUang_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtTagihan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
