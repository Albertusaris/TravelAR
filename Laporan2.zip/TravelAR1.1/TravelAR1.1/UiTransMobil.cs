﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiTransMobil : UserControl
    {
        public UiTransMobil()
        {
            InitializeComponent();
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void btnPesan_Click(object sender, EventArgs e)
        {

            string query = "select top 1 id_transaksi from ms_trans_mobil order by id_transaksi desc";
            string id = autogenerateID("TM", query);

            string connectionstring = "integrated security=true;data source= DESKTOP-QVO3FSO\\SQLEXPRESS ;initial catalog=TravelAR";
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand insert = new SqlCommand("sp_inputtransmobil", connection);
            insert.CommandType = CommandType.StoredProcedure;

            insert.Parameters.AddWithValue("id_transaksi", id);
            insert.Parameters.AddWithValue("nama", txtNama.Text);
            insert.Parameters.AddWithValue("kota", txtKotaTujuan.Text);
            insert.Parameters.AddWithValue("jenis", cmbJenis.Text);
            insert.Parameters.AddWithValue("jml_penumpang", cmbJmlPenumpang.Text);
            insert.Parameters.AddWithValue("harga", txtHarga.Text);
            insert.Parameters.AddWithValue("tanggal", dtTanggal.Value.Date.ToShortDateString());
            insert.Parameters.AddWithValue("durasi", cmbDurasi.Text);
            insert.Parameters.AddWithValue("total", txtTotal.Text);
            insert.Parameters.AddWithValue("statuS", "Booking");


            try
            {
                connection.Open();
                insert.ExecuteNonQuery();
                //Clear();
                //Datagrid();
                //Refresh();
                SqlCommand sqlcmd = new SqlCommand("sp_updatetransaksimobil", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@jenis", cmbJenis.Text);
                sqlcmd.Parameters.AddWithValue("@jml_mobil", "1");

                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //reset();
                txtResult.Clear();
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "====================== TravelAR =======================\n";
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "\n";
                txtResult.Text += "Tanggal Pemesanan\t\t: " + dtTanggal.Value.Date.ToShortDateString() + "\n";
                txtResult.Text += "Nama Pemesan\t\t\t: " + txtNama.Text + "\n";
                txtResult.Text += "Jenis Mobil\t\t\t: " + cmbJenis.Text + "\n";
                txtResult.Text += "ID Booking\t\t\t: " + id + "\n";
                txtResult.Text += "\n";
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "Silahkan Lakukan Pembayaran\n";
                txtResult.Text += "=====================================================\n";

                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();


            }
            catch (Exception ex)
            {
                MessageBox.Show("Data Belum Tersimpan " + ex.Message);
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {

        }

        private void UiTransMobil_Load(object sender, EventArgs e)
        {
            txtResult.Hide();
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_getDataTransBus", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            mycmd.Parameters.AddWithValue("@id_transaksi", txtCariId.Text);
            mycmd.Parameters.AddWithValue("@status", "Terbayar");

            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            //Datagrid1();
            dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["nama"].HeaderText = "Nama Pemesan";
            dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
            dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
            dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
            dataGridView1.Columns["jenis"].HeaderText = "Jenis";
            dataGridView1.Columns["droppoint"].HeaderText = "Droppoint";
            dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
            dataGridView1.Columns["jam"].HeaderText = "Jam";
            dataGridView1.Columns["harga"].HeaderText = "Harga";
            dataGridView1.Columns["jml_penumpang"].HeaderText = "Jumlah Tiket";
            dataGridView1.Columns["total"].HeaderText = "Total";
            dataGridView1.Columns["status"].HeaderText = "Status";
            dataGridView1.Columns[4].DefaultCellStyle.Format = "MM/dd/yyyy";
            dataGridView1.Columns[9].DefaultCellStyle.Format = "Rp #,###.00";
            dataGridView1.Columns[11].DefaultCellStyle.Format = "Rp #,###.00";
        }

        private void cmbJenis_SelectedValueChanged(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlCommand mycmd = new SqlCommand("SELECT harga FROM ms_mobil WHERE jenis = '" + cmbJenis.Text + "'", connection);
            connection.Open();
            mycmd.ExecuteNonQuery();
            SqlDataReader dr;
            dr = mycmd.ExecuteReader();
            while (dr.Read())
            {
                string harga = (string)dr["harga"].ToString();
                txtHarga.Text = harga;

            }
            connection.Close();
        }
    }
}
