﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace TravelAR1._1
{
    public partial class membercariupdate : UserControl
    {
        public membercariupdate()
        {
            InitializeComponent();
        }

        private void membercariupdate_Load(object sender, EventArgs e)
        {
            Datagrid();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmember", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }
        private void clear()
        {
            txtIdmember.Text = "";
            txtNama.Text = "";
            txtNik.Text = "";
            txtEmail.Text = "";
            txtNotelp.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtIdmember.Text == "" || txtNama.Text == "" || txtNik.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatemember", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@no_telp", txtNotelp.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@id_member", txtIdmember.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil DiUpdate!");
                clear();
                Datagrid();
            }
                
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            //if (dataGridView1.CurrentRow.Index != -1)
            //{
                txtIdmember.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtNama.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                txtNik.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txtEmail.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                txtNotelp.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            //}
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtIdmember.Text == "" || txtNama.Text == "" || txtNik.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletemember", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id_member", txtIdmember.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    Reset();
                    Datagrid();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
                
        }
        private void Reset()
        {
            txtIdmember.Text = "";
            txtNama.Text = "";
            txtNik.Text = "";
            txtEmail.Text = "";
            txtNotelp.Text = ""; 

        }

        private void txtNotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            //setting format regular expression
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            //Regex regex = new Regex(regexPattern);
            if (Regex.IsMatch(txtEmail.Text, regexPattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.txtEmail, "Format Tidak Sesuai");
                return;
            }
        }
    }
}
