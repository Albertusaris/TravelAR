﻿namespace TravelAR1._1
{
    partial class UiPayTicketBus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiPayTicketBus));
            this.txtCariIdTrans = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnCariTrans = new Bunifu.Framework.UI.BunifuThinButton2();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNama = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtKotaTujuan = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtTanggal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtJenis = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtNoPlat = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtJam = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtJmlTiket = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtTotal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtIdMember = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtCariMember = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtIdMem = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtEmail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTagihan = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnKonfirm = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtKembalian = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtUang = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtStatus = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label17 = new System.Windows.Forms.Label();
            this.lblCoba = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.RichTextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.txtDroppoint = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtKotaAsal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCariIdTrans
            // 
            this.txtCariIdTrans.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCariIdTrans.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCariIdTrans.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCariIdTrans.HintForeColor = System.Drawing.Color.Empty;
            this.txtCariIdTrans.HintText = "";
            this.txtCariIdTrans.isPassword = false;
            this.txtCariIdTrans.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtCariIdTrans.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtCariIdTrans.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtCariIdTrans.LineThickness = 3;
            this.txtCariIdTrans.Location = new System.Drawing.Point(13, 5);
            this.txtCariIdTrans.Margin = new System.Windows.Forms.Padding(4);
            this.txtCariIdTrans.Name = "txtCariIdTrans";
            this.txtCariIdTrans.Size = new System.Drawing.Size(213, 25);
            this.txtCariIdTrans.TabIndex = 0;
            this.txtCariIdTrans.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCariIdTrans.OnValueChanged += new System.EventHandler(this.txtCariIdTrans_OnValueChanged);
            // 
            // btnCariTrans
            // 
            this.btnCariTrans.ActiveBorderThickness = 1;
            this.btnCariTrans.ActiveCornerRadius = 20;
            this.btnCariTrans.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.btnCariTrans.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.BackColor = System.Drawing.Color.White;
            this.btnCariTrans.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCariTrans.BackgroundImage")));
            this.btnCariTrans.ButtonText = "Cari";
            this.btnCariTrans.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCariTrans.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCariTrans.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.IdleBorderThickness = 1;
            this.btnCariTrans.IdleCornerRadius = 20;
            this.btnCariTrans.IdleFillColor = System.Drawing.Color.White;
            this.btnCariTrans.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.Location = new System.Drawing.Point(235, 0);
            this.btnCariTrans.Margin = new System.Windows.Forms.Padding(5);
            this.btnCariTrans.Name = "btnCariTrans";
            this.btnCariTrans.Size = new System.Drawing.Size(89, 35);
            this.btnCariTrans.TabIndex = 1;
            this.btnCariTrans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCariTrans.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 37);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(857, 160);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.IndianRed;
            this.label22.Location = new System.Drawing.Point(209, 249);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 20);
            this.label22.TabIndex = 134;
            this.label22.Text = "Jam";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.IndianRed;
            this.label20.Location = new System.Drawing.Point(209, 200);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 20);
            this.label20.TabIndex = 131;
            this.label20.Text = "No Plat";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.IndianRed;
            this.label15.Location = new System.Drawing.Point(858, 402);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 20);
            this.label15.TabIndex = 125;
            this.label15.Text = ":";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.IndianRed;
            this.label16.Location = new System.Drawing.Point(209, 352);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 20);
            this.label16.TabIndex = 124;
            this.label16.Text = "Total";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.IndianRed;
            this.label12.Location = new System.Drawing.Point(209, 302);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 20);
            this.label12.TabIndex = 118;
            this.label12.Text = "Jml Tiket";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.IndianRed;
            this.label6.Location = new System.Drawing.Point(9, 406);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 115;
            this.label6.Text = "Jenis";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.IndianRed;
            this.label3.Location = new System.Drawing.Point(9, 358);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 119;
            this.label3.Text = "Tanggal";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.IndianRed;
            this.label2.Location = new System.Drawing.Point(9, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 20);
            this.label2.TabIndex = 118;
            this.label2.Text = "Kota Tujuan";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(9, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 20);
            this.label1.TabIndex = 117;
            this.label1.Text = "Nama Pemesan";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtNama
            // 
            this.txtNama.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNama.Enabled = false;
            this.txtNama.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtNama.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNama.HintForeColor = System.Drawing.Color.Empty;
            this.txtNama.HintText = "";
            this.txtNama.isPassword = false;
            this.txtNama.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtNama.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtNama.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtNama.LineThickness = 3;
            this.txtNama.Location = new System.Drawing.Point(13, 221);
            this.txtNama.Margin = new System.Windows.Forms.Padding(4);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(179, 21);
            this.txtNama.TabIndex = 136;
            this.txtNama.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNama.OnValueChanged += new System.EventHandler(this.txtNama_OnValueChanged);
            // 
            // txtKotaTujuan
            // 
            this.txtKotaTujuan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtKotaTujuan.Enabled = false;
            this.txtKotaTujuan.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtKotaTujuan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtKotaTujuan.HintForeColor = System.Drawing.Color.Empty;
            this.txtKotaTujuan.HintText = "";
            this.txtKotaTujuan.isPassword = false;
            this.txtKotaTujuan.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtKotaTujuan.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtKotaTujuan.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtKotaTujuan.LineThickness = 3;
            this.txtKotaTujuan.Location = new System.Drawing.Point(13, 327);
            this.txtKotaTujuan.Margin = new System.Windows.Forms.Padding(4);
            this.txtKotaTujuan.Name = "txtKotaTujuan";
            this.txtKotaTujuan.Size = new System.Drawing.Size(179, 21);
            this.txtKotaTujuan.TabIndex = 138;
            this.txtKotaTujuan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtKotaTujuan.OnValueChanged += new System.EventHandler(this.txtKotaTujuan_OnValueChanged);
            // 
            // txtTanggal
            // 
            this.txtTanggal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTanggal.Enabled = false;
            this.txtTanggal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTanggal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTanggal.HintForeColor = System.Drawing.Color.Empty;
            this.txtTanggal.HintText = "";
            this.txtTanggal.isPassword = false;
            this.txtTanggal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTanggal.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTanggal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTanggal.LineThickness = 3;
            this.txtTanggal.Location = new System.Drawing.Point(13, 382);
            this.txtTanggal.Margin = new System.Windows.Forms.Padding(4);
            this.txtTanggal.Name = "txtTanggal";
            this.txtTanggal.Size = new System.Drawing.Size(179, 21);
            this.txtTanggal.TabIndex = 139;
            this.txtTanggal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTanggal.OnValueChanged += new System.EventHandler(this.txtTanggal_OnValueChanged);
            // 
            // txtJenis
            // 
            this.txtJenis.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJenis.Enabled = false;
            this.txtJenis.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJenis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtJenis.HintForeColor = System.Drawing.Color.Empty;
            this.txtJenis.HintText = "";
            this.txtJenis.isPassword = false;
            this.txtJenis.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtJenis.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtJenis.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtJenis.LineThickness = 3;
            this.txtJenis.Location = new System.Drawing.Point(13, 427);
            this.txtJenis.Margin = new System.Windows.Forms.Padding(4);
            this.txtJenis.Name = "txtJenis";
            this.txtJenis.Size = new System.Drawing.Size(179, 24);
            this.txtJenis.TabIndex = 140;
            this.txtJenis.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtJenis.OnValueChanged += new System.EventHandler(this.bunifuMaterialTextbox6_OnValueChanged);
            // 
            // txtNoPlat
            // 
            this.txtNoPlat.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNoPlat.Enabled = false;
            this.txtNoPlat.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtNoPlat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNoPlat.HintForeColor = System.Drawing.Color.Empty;
            this.txtNoPlat.HintText = "";
            this.txtNoPlat.isPassword = false;
            this.txtNoPlat.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtNoPlat.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtNoPlat.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtNoPlat.LineThickness = 3;
            this.txtNoPlat.Location = new System.Drawing.Point(213, 221);
            this.txtNoPlat.Margin = new System.Windows.Forms.Padding(4);
            this.txtNoPlat.Name = "txtNoPlat";
            this.txtNoPlat.Size = new System.Drawing.Size(150, 21);
            this.txtNoPlat.TabIndex = 142;
            this.txtNoPlat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNoPlat.OnValueChanged += new System.EventHandler(this.txtNoPlat_OnValueChanged);
            // 
            // txtJam
            // 
            this.txtJam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJam.Enabled = false;
            this.txtJam.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJam.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtJam.HintForeColor = System.Drawing.Color.Empty;
            this.txtJam.HintText = "";
            this.txtJam.isPassword = false;
            this.txtJam.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtJam.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtJam.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtJam.LineThickness = 3;
            this.txtJam.Location = new System.Drawing.Point(213, 273);
            this.txtJam.Margin = new System.Windows.Forms.Padding(4);
            this.txtJam.Name = "txtJam";
            this.txtJam.Size = new System.Drawing.Size(150, 21);
            this.txtJam.TabIndex = 143;
            this.txtJam.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtJam.OnValueChanged += new System.EventHandler(this.txtJam_OnValueChanged);
            // 
            // txtJmlTiket
            // 
            this.txtJmlTiket.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJmlTiket.Enabled = false;
            this.txtJmlTiket.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJmlTiket.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtJmlTiket.HintForeColor = System.Drawing.Color.Empty;
            this.txtJmlTiket.HintText = "";
            this.txtJmlTiket.isPassword = false;
            this.txtJmlTiket.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtJmlTiket.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtJmlTiket.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtJmlTiket.LineThickness = 3;
            this.txtJmlTiket.Location = new System.Drawing.Point(213, 327);
            this.txtJmlTiket.Margin = new System.Windows.Forms.Padding(4);
            this.txtJmlTiket.Name = "txtJmlTiket";
            this.txtJmlTiket.Size = new System.Drawing.Size(150, 21);
            this.txtJmlTiket.TabIndex = 144;
            this.txtJmlTiket.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtJmlTiket.OnValueChanged += new System.EventHandler(this.txtJmlTiket_OnValueChanged);
            // 
            // txtTotal
            // 
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotal.Enabled = false;
            this.txtTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTotal.HintForeColor = System.Drawing.Color.Empty;
            this.txtTotal.HintText = "";
            this.txtTotal.isPassword = false;
            this.txtTotal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTotal.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTotal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTotal.LineThickness = 3;
            this.txtTotal.Location = new System.Drawing.Point(213, 382);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(150, 21);
            this.txtTotal.TabIndex = 145;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTotal.OnValueChanged += new System.EventHandler(this.txtTotal_OnValueChanged);
            this.txtTotal.Load += new System.EventHandler(this.txtTotal_Load);
            this.txtTotal.Leave += new System.EventHandler(this.txtTotal_Leave);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(404, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 151;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(404, 240);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(466, 108);
            this.dataGridView2.TabIndex = 152;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.DoubleClick += new System.EventHandler(this.dataGridView2_DoubleClick);
            // 
            // txtIdMember
            // 
            this.txtIdMember.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdMember.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtIdMember.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtIdMember.HintForeColor = System.Drawing.Color.Empty;
            this.txtIdMember.HintText = "";
            this.txtIdMember.isPassword = false;
            this.txtIdMember.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtIdMember.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtIdMember.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtIdMember.LineThickness = 3;
            this.txtIdMember.Location = new System.Drawing.Point(607, 212);
            this.txtIdMember.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdMember.Name = "txtIdMember";
            this.txtIdMember.Size = new System.Drawing.Size(150, 21);
            this.txtIdMember.TabIndex = 153;
            this.txtIdMember.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtIdMember.OnValueChanged += new System.EventHandler(this.txtIdMember_OnValueChanged);
            // 
            // txtCariMember
            // 
            this.txtCariMember.ActiveBorderThickness = 1;
            this.txtCariMember.ActiveCornerRadius = 20;
            this.txtCariMember.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.txtCariMember.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.BackColor = System.Drawing.Color.White;
            this.txtCariMember.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCariMember.BackgroundImage")));
            this.txtCariMember.ButtonText = "Cari";
            this.txtCariMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtCariMember.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCariMember.ForeColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.IdleBorderThickness = 1;
            this.txtCariMember.IdleCornerRadius = 20;
            this.txtCariMember.IdleFillColor = System.Drawing.Color.White;
            this.txtCariMember.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.Location = new System.Drawing.Point(766, 205);
            this.txtCariMember.Margin = new System.Windows.Forms.Padding(5);
            this.txtCariMember.Name = "txtCariMember";
            this.txtCariMember.Size = new System.Drawing.Size(89, 35);
            this.txtCariMember.TabIndex = 154;
            this.txtCariMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtCariMember.Click += new System.EventHandler(this.txtCariMember_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.IndianRed;
            this.label5.Location = new System.Drawing.Point(400, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 20);
            this.label5.TabIndex = 155;
            this.label5.Text = "Member";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.IndianRed;
            this.label7.Location = new System.Drawing.Point(400, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 20);
            this.label7.TabIndex = 156;
            this.label7.Text = "ID Member";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtIdMem
            // 
            this.txtIdMem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdMem.Enabled = false;
            this.txtIdMem.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtIdMem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtIdMem.HintForeColor = System.Drawing.Color.Empty;
            this.txtIdMem.HintText = "";
            this.txtIdMem.isPassword = false;
            this.txtIdMem.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtIdMem.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtIdMem.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtIdMem.LineThickness = 3;
            this.txtIdMem.Location = new System.Drawing.Point(504, 358);
            this.txtIdMem.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdMem.Name = "txtIdMem";
            this.txtIdMem.Size = new System.Drawing.Size(107, 21);
            this.txtIdMem.TabIndex = 157;
            this.txtIdMem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtIdMem.OnValueChanged += new System.EventHandler(this.txtIdMem_OnValueChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmail.Enabled = false;
            this.txtEmail.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEmail.HintForeColor = System.Drawing.Color.Empty;
            this.txtEmail.HintText = "";
            this.txtEmail.isPassword = false;
            this.txtEmail.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtEmail.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtEmail.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtEmail.LineThickness = 3;
            this.txtEmail.Location = new System.Drawing.Point(690, 357);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(180, 21);
            this.txtEmail.TabIndex = 159;
            this.txtEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEmail.OnValueChanged += new System.EventHandler(this.txtEmail_OnValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.IndianRed;
            this.label8.Location = new System.Drawing.Point(630, 358);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 20);
            this.label8.TabIndex = 158;
            this.label8.Text = "Email";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTagihan);
            this.groupBox1.Controls.Add(this.btnKonfirm);
            this.groupBox1.Controls.Add(this.txtKembalian);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.txtUang);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(404, 381);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(466, 126);
            this.groupBox1.TabIndex = 160;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pembayaran";
            // 
            // txtTagihan
            // 
            this.txtTagihan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTagihan.Enabled = false;
            this.txtTagihan.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTagihan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTagihan.HintForeColor = System.Drawing.Color.Empty;
            this.txtTagihan.HintText = "";
            this.txtTagihan.isPassword = false;
            this.txtTagihan.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTagihan.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTagihan.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTagihan.LineThickness = 3;
            this.txtTagihan.Location = new System.Drawing.Point(39, 48);
            this.txtTagihan.Margin = new System.Windows.Forms.Padding(4);
            this.txtTagihan.Name = "txtTagihan";
            this.txtTagihan.Size = new System.Drawing.Size(126, 21);
            this.txtTagihan.TabIndex = 166;
            this.txtTagihan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTagihan.OnValueChanged += new System.EventHandler(this.txtTagihan_OnValueChanged);
            this.txtTagihan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTagihan_KeyPress);
            this.txtTagihan.Leave += new System.EventHandler(this.txtTagihan_Leave);
            // 
            // btnKonfirm
            // 
            this.btnKonfirm.ActiveBorderThickness = 1;
            this.btnKonfirm.ActiveCornerRadius = 20;
            this.btnKonfirm.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.btnKonfirm.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.BackColor = System.Drawing.Color.White;
            this.btnKonfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKonfirm.BackgroundImage")));
            this.btnKonfirm.ButtonText = "Konfirmasi";
            this.btnKonfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKonfirm.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKonfirm.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.IdleBorderThickness = 1;
            this.btnKonfirm.IdleCornerRadius = 20;
            this.btnKonfirm.IdleFillColor = System.Drawing.Color.White;
            this.btnKonfirm.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.Location = new System.Drawing.Point(286, 74);
            this.btnKonfirm.Margin = new System.Windows.Forms.Padding(5);
            this.btnKonfirm.Name = "btnKonfirm";
            this.btnKonfirm.Size = new System.Drawing.Size(104, 35);
            this.btnKonfirm.TabIndex = 161;
            this.btnKonfirm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnKonfirm.Click += new System.EventHandler(this.btnKonfirm_Click);
            // 
            // txtKembalian
            // 
            this.txtKembalian.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtKembalian.Enabled = false;
            this.txtKembalian.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtKembalian.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtKembalian.HintForeColor = System.Drawing.Color.Empty;
            this.txtKembalian.HintText = "";
            this.txtKembalian.isPassword = false;
            this.txtKembalian.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtKembalian.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtKembalian.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtKembalian.LineThickness = 3;
            this.txtKembalian.Location = new System.Drawing.Point(294, 43);
            this.txtKembalian.Margin = new System.Windows.Forms.Padding(4);
            this.txtKembalian.Name = "txtKembalian";
            this.txtKembalian.Size = new System.Drawing.Size(126, 21);
            this.txtKembalian.TabIndex = 165;
            this.txtKembalian.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtKembalian.OnValueChanged += new System.EventHandler(this.txtKembalian_OnValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.IndianRed;
            this.label19.Location = new System.Drawing.Point(13, 21);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 20);
            this.label19.TabIndex = 167;
            this.label19.Text = "Tagihan";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.IndianRed;
            this.label21.Location = new System.Drawing.Point(10, 48);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(32, 20);
            this.label21.TabIndex = 168;
            this.label21.Text = "Rp";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // txtUang
            // 
            this.txtUang.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUang.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtUang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtUang.HintForeColor = System.Drawing.Color.Empty;
            this.txtUang.HintText = "";
            this.txtUang.isPassword = false;
            this.txtUang.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtUang.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtUang.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtUang.LineThickness = 3;
            this.txtUang.Location = new System.Drawing.Point(32, 100);
            this.txtUang.Margin = new System.Windows.Forms.Padding(4);
            this.txtUang.Name = "txtUang";
            this.txtUang.Size = new System.Drawing.Size(126, 21);
            this.txtUang.TabIndex = 161;
            this.txtUang.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtUang.OnValueChanged += new System.EventHandler(this.txtUang_OnValueChanged);
            this.txtUang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuMaterialTextbox15_KeyPress);
            this.txtUang.Leave += new System.EventHandler(this.txtUang_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.IndianRed;
            this.label11.Location = new System.Drawing.Point(268, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 20);
            this.label11.TabIndex = 164;
            this.label11.Text = "Kembalian";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.IndianRed;
            this.label13.Location = new System.Drawing.Point(265, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 20);
            this.label13.TabIndex = 163;
            this.label13.Text = "Rp";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.IndianRed;
            this.label10.Location = new System.Drawing.Point(6, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 20);
            this.label10.TabIndex = 161;
            this.label10.Text = "Uang Yang Dibayarkan";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.IndianRed;
            this.label9.Location = new System.Drawing.Point(3, 100);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 20);
            this.label9.TabIndex = 161;
            this.label9.Text = "Rp";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtStatus
            // 
            this.txtStatus.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtStatus.Enabled = false;
            this.txtStatus.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtStatus.HintForeColor = System.Drawing.Color.Empty;
            this.txtStatus.HintText = "";
            this.txtStatus.isPassword = false;
            this.txtStatus.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtStatus.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtStatus.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtStatus.LineThickness = 3;
            this.txtStatus.Location = new System.Drawing.Point(213, 432);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(4);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(150, 21);
            this.txtStatus.TabIndex = 162;
            this.txtStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.IndianRed;
            this.label14.Location = new System.Drawing.Point(209, 406);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 20);
            this.label14.TabIndex = 161;
            this.label14.Text = "Status";
            // 
            // txtId
            // 
            this.txtId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtId.Enabled = false;
            this.txtId.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtId.HintForeColor = System.Drawing.Color.Empty;
            this.txtId.HintText = "";
            this.txtId.isPassword = false;
            this.txtId.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtId.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtId.LineThickness = 3;
            this.txtId.Location = new System.Drawing.Point(213, 481);
            this.txtId.Margin = new System.Windows.Forms.Padding(4);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(150, 21);
            this.txtId.TabIndex = 164;
            this.txtId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.IndianRed;
            this.label17.Location = new System.Drawing.Point(209, 455);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(28, 20);
            this.label17.TabIndex = 163;
            this.label17.Text = "ID";
            // 
            // lblCoba
            // 
            this.lblCoba.AutoSize = true;
            this.lblCoba.Location = new System.Drawing.Point(535, 17);
            this.lblCoba.Name = "lblCoba";
            this.lblCoba.Size = new System.Drawing.Size(0, 13);
            this.lblCoba.TabIndex = 165;
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(438, -147);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(320, 367);
            this.txtResult.TabIndex = 166;
            this.txtResult.Text = "";
            this.txtResult.TextChanged += new System.EventHandler(this.txtResult_TextChanged);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // txtDroppoint
            // 
            this.txtDroppoint.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDroppoint.Enabled = false;
            this.txtDroppoint.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtDroppoint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDroppoint.HintForeColor = System.Drawing.Color.Empty;
            this.txtDroppoint.HintText = "";
            this.txtDroppoint.isPassword = false;
            this.txtDroppoint.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtDroppoint.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtDroppoint.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtDroppoint.LineThickness = 3;
            this.txtDroppoint.Location = new System.Drawing.Point(13, 476);
            this.txtDroppoint.Margin = new System.Windows.Forms.Padding(4);
            this.txtDroppoint.Name = "txtDroppoint";
            this.txtDroppoint.Size = new System.Drawing.Size(179, 23);
            this.txtDroppoint.TabIndex = 141;
            this.txtDroppoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtDroppoint.OnValueChanged += new System.EventHandler(this.txtDroppoint_OnValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.IndianRed;
            this.label18.Location = new System.Drawing.Point(9, 455);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(94, 20);
            this.label18.TabIndex = 128;
            this.label18.Text = "Drop Point";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // txtKotaAsal
            // 
            this.txtKotaAsal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtKotaAsal.Enabled = false;
            this.txtKotaAsal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtKotaAsal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtKotaAsal.HintForeColor = System.Drawing.Color.Empty;
            this.txtKotaAsal.HintText = "";
            this.txtKotaAsal.isPassword = false;
            this.txtKotaAsal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtKotaAsal.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtKotaAsal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtKotaAsal.LineThickness = 3;
            this.txtKotaAsal.Location = new System.Drawing.Point(13, 273);
            this.txtKotaAsal.Margin = new System.Windows.Forms.Padding(4);
            this.txtKotaAsal.Name = "txtKotaAsal";
            this.txtKotaAsal.Size = new System.Drawing.Size(179, 21);
            this.txtKotaAsal.TabIndex = 137;
            this.txtKotaAsal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.IndianRed;
            this.label4.Location = new System.Drawing.Point(9, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 120;
            this.label4.Text = "Kota Asal";
            // 
            // UiPayTicketBus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.lblCoba);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtIdMem);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCariMember);
            this.Controls.Add(this.txtIdMember);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtJmlTiket);
            this.Controls.Add(this.txtJam);
            this.Controls.Add(this.txtNoPlat);
            this.Controls.Add(this.txtDroppoint);
            this.Controls.Add(this.txtJenis);
            this.Controls.Add(this.txtTanggal);
            this.Controls.Add(this.txtKotaTujuan);
            this.Controls.Add(this.txtKotaAsal);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btnCariTrans);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtCariIdTrans);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label12);
            this.Name = "UiPayTicketBus";
            this.Size = new System.Drawing.Size(883, 519);
            this.Load += new System.EventHandler(this.UiPayTicketBus_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuMaterialTextbox txtCariIdTrans;
        private Bunifu.Framework.UI.BunifuThinButton2 btnCariTrans;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtNama;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtKotaTujuan;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTanggal;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJenis;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtNoPlat;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJam;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJmlTiket;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTotal;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtIdMember;
        private Bunifu.Framework.UI.BunifuThinButton2 txtCariMember;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtIdMem;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnKonfirm;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtKembalian;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtUang;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtStatus;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblCoba;
        private System.Windows.Forms.RichTextBox txtResult;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTagihan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtDroppoint;
        private System.Windows.Forms.Label label18;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtKotaAsal;
        private System.Windows.Forms.Label label4;
    }
}
