﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelAR1._1
{
    public partial class UiCustomerService : Form
    {
        public UiCustomerService()
        {
            InitializeComponent();
        }

        private void btnclose2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDroppoint_Click(object sender, EventArgs e)
        {
            uiPayTicketBus1.Hide();
            uiPayTicketWisata1.Show();
            uiPayTicketBus1.Hide();
            uiPayHotel1.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 from = new Form1();
            from.Show();
        }

        private void btnTourguide_Click(object sender, EventArgs e)
        {
            uiPayHotel1.Show();
            uiPayTicketBus1.Hide();
            uiPayTicketWisata1.Hide();
            uiPayMobil1.Hide();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            uiPayHotel1.Hide();
            uiPayTicketBus1.Hide();
            uiPayTicketWisata1.Hide();
            uiPayMobil1.Hide();
            
        }

        private void btnKendaraan_Click(object sender, EventArgs e)
        {
            uiPayTicketBus1.Show();
            uiPayTicketWisata1.Hide();
            uiPayMobil1.Hide();
            uiPayHotel1.Hide();
        }
    }
}
