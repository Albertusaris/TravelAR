﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiPayTicketWisata : UserControl
    {
        public UiPayTicketWisata()
        {
            InitializeComponent();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihattransaksiwisata", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["nama"].HeaderText = "Nama Pemesan";
            dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
            dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
            dataGridView1.Columns["nama_wisata"].HeaderText = "Nama Wisata";
            dataGridView1.Columns["harga"].HeaderText = "Harga";
            dataGridView1.Columns["jml_tiket"].HeaderText = "Jumlah Tiket";
            dataGridView1.Columns["total"].HeaderText = "Total";
            dataGridView1.Columns["status"].HeaderText = "Status";

            dataGridView1.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
            dataGridView1.Columns[5].DefaultCellStyle.Format = "Rp #,###.00";
            dataGridView1.Columns[7].DefaultCellStyle.Format = "Rp #,###.00";
        }

        private void UiPayTicketWisata_Load(object sender, EventArgs e)
        {
            Datagrid();
            DatagridMember();
            txtResult.Hide();
        }
        public void DatagridMember()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmember", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView2.DataSource = dt;
        }

        private void btnCariTrans_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_getDataPayWisata", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            mycmd.Parameters.AddWithValue("@id_transaksi", txtCariIdTrans.Text);
            mycmd.Parameters.AddWithValue("@status", "Booking");

            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;

            dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["nama"].HeaderText = "Nama Pemesan";
            dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
            dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
            dataGridView1.Columns["nama_wisata"].HeaderText = "Nama Wisata";
            dataGridView1.Columns["harga"].HeaderText = "Harga";
            dataGridView1.Columns["jml_tiket"].HeaderText = "Jumlah Tiket";
            dataGridView1.Columns["total"].HeaderText = "Total";
            dataGridView1.Columns["status"].HeaderText = "Status";

            dataGridView1.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
            dataGridView1.Columns[5].DefaultCellStyle.Format = "Rp #,###.00";
            dataGridView1.Columns[7].DefaultCellStyle.Format = "Rp #,###.00";
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtNama.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtKotaTujuan.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtTanggal.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtTempatWisata.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtHarga.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtJml.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtTotal.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtId.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            CekUang();
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txtIdMem.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtEmail.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
        }
        private void CekUang()
        {
            if (txtIdMem.Text == "" || txtEmail.Text == "")
            {
                txtTagihan.Text = txtTotal.Text;
            }
            else
            {
                try
                {
                    txtTagihan.Text = (float.Parse(txtTotal.Text) * float.Parse("0.90")).ToString();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error" + Ex);
                }
            }

        }

        private void txtUang_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtUang_Leave(object sender, EventArgs e)
        {
            try
            {
                txtKembalian.Text = (float.Parse(txtUang.Text) - float.Parse(txtTagihan.Text)).ToString();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error" + Ex);
            }
        }

        private void txtTagihan_Leave(object sender, EventArgs e)
        {
            //try
            //{
            //    txtTagihan.Text = (float.Parse(txtTotal.Text) / float.Parse("0.90")).ToString();
            //}
            //catch (Exception Ex)
            //{
            //    MessageBox.Show("Error" + Ex);
            //}
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtResult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void btnKonfirm_Click(object sender, EventArgs e)
        {
            if(txtNama.Text=="" || txtKotaTujuan.Text=="")
            {
                MessageBox.Show("Isi Data dengan lengkap");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatestatuswisata", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@status", "Terbayar");
                sqlcmd.Parameters.AddWithValue("@id_transaksi", txtId.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Pembayaran Berhasil");
                Datagrid();

                txtResult.Clear();
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "====================== TravelAR =======================\n";
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "\n";
                txtResult.Text += "Tanggal Pemesanan\t\t: " + txtTanggal.Text + "\n";
                txtResult.Text += "Nama Pemesan\t\t\t: " + txtNama.Text + "\n";
                txtResult.Text += "Nama Wisata\t\t\t: " + txtTempatWisata.Text + "\n";
                txtResult.Text += "Jumlah Tiket\t\t\t: " + txtJml.Text + "\n";
                txtResult.Text += "\n";
                txtResult.Text += "=====================================================\n";
                txtResult.Text += "Total Pembayaran\t\t: " + txtTagihan.Text + "\n";
                txtResult.Text += "Uang Yang Dibayarkan\t\t: " + txtUang.Text + "\n";
                txtResult.Text += "Kembalian\t\t\t: " + txtKembalian.Text + "\n";
                txtResult.Text += "\n";
                txtResult.Text += "=====================================================\n";

                txtResult.Text += "============= Terimakasih Telah Bertransaksi ===============\n";


                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            }
           
        }
    }
}
