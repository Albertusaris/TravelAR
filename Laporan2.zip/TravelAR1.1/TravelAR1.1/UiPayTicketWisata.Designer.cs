﻿namespace TravelAR1._1
{
    partial class UiPayTicketWisata
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiPayTicketWisata));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnCariTrans = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtCariIdTrans = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtTotal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtJml = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtHarga = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtTempatWisata = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtTanggal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtKotaTujuan = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtNama = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCariMember = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtIdMember = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtEmail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtIdMem = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTagihan = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnKonfirm = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtKembalian = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtUang = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.RichTextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 42);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(857, 160);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // btnCariTrans
            // 
            this.btnCariTrans.ActiveBorderThickness = 1;
            this.btnCariTrans.ActiveCornerRadius = 20;
            this.btnCariTrans.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.btnCariTrans.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.BackColor = System.Drawing.SystemColors.Control;
            this.btnCariTrans.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCariTrans.BackgroundImage")));
            this.btnCariTrans.ButtonText = "Cari";
            this.btnCariTrans.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCariTrans.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCariTrans.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.IdleBorderThickness = 1;
            this.btnCariTrans.IdleCornerRadius = 20;
            this.btnCariTrans.IdleFillColor = System.Drawing.Color.White;
            this.btnCariTrans.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnCariTrans.Location = new System.Drawing.Point(236, 5);
            this.btnCariTrans.Margin = new System.Windows.Forms.Padding(5);
            this.btnCariTrans.Name = "btnCariTrans";
            this.btnCariTrans.Size = new System.Drawing.Size(89, 35);
            this.btnCariTrans.TabIndex = 4;
            this.btnCariTrans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCariTrans.Click += new System.EventHandler(this.btnCariTrans_Click);
            // 
            // txtCariIdTrans
            // 
            this.txtCariIdTrans.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCariIdTrans.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCariIdTrans.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCariIdTrans.HintForeColor = System.Drawing.Color.Empty;
            this.txtCariIdTrans.HintText = "";
            this.txtCariIdTrans.isPassword = false;
            this.txtCariIdTrans.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtCariIdTrans.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtCariIdTrans.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtCariIdTrans.LineThickness = 3;
            this.txtCariIdTrans.Location = new System.Drawing.Point(14, 10);
            this.txtCariIdTrans.Margin = new System.Windows.Forms.Padding(4);
            this.txtCariIdTrans.Name = "txtCariIdTrans";
            this.txtCariIdTrans.Size = new System.Drawing.Size(213, 25);
            this.txtCariIdTrans.TabIndex = 3;
            this.txtCariIdTrans.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtTotal
            // 
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTotal.HintForeColor = System.Drawing.Color.Empty;
            this.txtTotal.HintText = "";
            this.txtTotal.isPassword = false;
            this.txtTotal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTotal.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTotal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTotal.LineThickness = 3;
            this.txtTotal.Location = new System.Drawing.Point(214, 278);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(150, 21);
            this.txtTotal.TabIndex = 163;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtJml
            // 
            this.txtJml.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJml.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJml.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtJml.HintForeColor = System.Drawing.Color.Empty;
            this.txtJml.HintText = "";
            this.txtJml.isPassword = false;
            this.txtJml.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtJml.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtJml.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtJml.LineThickness = 3;
            this.txtJml.Location = new System.Drawing.Point(214, 226);
            this.txtJml.Margin = new System.Windows.Forms.Padding(4);
            this.txtJml.Name = "txtJml";
            this.txtJml.Size = new System.Drawing.Size(150, 21);
            this.txtJml.TabIndex = 160;
            this.txtJml.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtHarga
            // 
            this.txtHarga.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHarga.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtHarga.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtHarga.HintForeColor = System.Drawing.Color.Empty;
            this.txtHarga.HintText = "";
            this.txtHarga.isPassword = false;
            this.txtHarga.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtHarga.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtHarga.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtHarga.LineThickness = 3;
            this.txtHarga.Location = new System.Drawing.Point(14, 441);
            this.txtHarga.Margin = new System.Windows.Forms.Padding(4);
            this.txtHarga.Name = "txtHarga";
            this.txtHarga.Size = new System.Drawing.Size(179, 23);
            this.txtHarga.TabIndex = 159;
            this.txtHarga.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtTempatWisata
            // 
            this.txtTempatWisata.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTempatWisata.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTempatWisata.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTempatWisata.HintForeColor = System.Drawing.Color.Empty;
            this.txtTempatWisata.HintText = "";
            this.txtTempatWisata.isPassword = false;
            this.txtTempatWisata.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTempatWisata.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTempatWisata.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTempatWisata.LineThickness = 3;
            this.txtTempatWisata.Location = new System.Drawing.Point(14, 378);
            this.txtTempatWisata.Margin = new System.Windows.Forms.Padding(4);
            this.txtTempatWisata.Name = "txtTempatWisata";
            this.txtTempatWisata.Size = new System.Drawing.Size(179, 24);
            this.txtTempatWisata.TabIndex = 158;
            this.txtTempatWisata.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtTanggal
            // 
            this.txtTanggal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTanggal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTanggal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTanggal.HintForeColor = System.Drawing.Color.Empty;
            this.txtTanggal.HintText = "";
            this.txtTanggal.isPassword = false;
            this.txtTanggal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTanggal.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTanggal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTanggal.LineThickness = 3;
            this.txtTanggal.Location = new System.Drawing.Point(14, 331);
            this.txtTanggal.Margin = new System.Windows.Forms.Padding(4);
            this.txtTanggal.Name = "txtTanggal";
            this.txtTanggal.Size = new System.Drawing.Size(179, 21);
            this.txtTanggal.TabIndex = 157;
            this.txtTanggal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtKotaTujuan
            // 
            this.txtKotaTujuan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtKotaTujuan.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtKotaTujuan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtKotaTujuan.HintForeColor = System.Drawing.Color.Empty;
            this.txtKotaTujuan.HintText = "";
            this.txtKotaTujuan.isPassword = false;
            this.txtKotaTujuan.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtKotaTujuan.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtKotaTujuan.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtKotaTujuan.LineThickness = 3;
            this.txtKotaTujuan.Location = new System.Drawing.Point(14, 278);
            this.txtKotaTujuan.Margin = new System.Windows.Forms.Padding(4);
            this.txtKotaTujuan.Name = "txtKotaTujuan";
            this.txtKotaTujuan.Size = new System.Drawing.Size(179, 21);
            this.txtKotaTujuan.TabIndex = 156;
            this.txtKotaTujuan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtNama
            // 
            this.txtNama.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNama.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtNama.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNama.HintForeColor = System.Drawing.Color.Empty;
            this.txtNama.HintText = "";
            this.txtNama.isPassword = false;
            this.txtNama.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtNama.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtNama.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtNama.LineThickness = 3;
            this.txtNama.Location = new System.Drawing.Point(14, 226);
            this.txtNama.Margin = new System.Windows.Forms.Padding(4);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(179, 21);
            this.txtNama.TabIndex = 155;
            this.txtNama.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.IndianRed;
            this.label3.Location = new System.Drawing.Point(10, 307);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 150;
            this.label3.Text = "Tanggal";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.IndianRed;
            this.label20.Location = new System.Drawing.Point(210, 205);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(110, 20);
            this.label20.TabIndex = 153;
            this.label20.Text = "Jumlah Tiket";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.IndianRed;
            this.label2.Location = new System.Drawing.Point(10, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 20);
            this.label2.TabIndex = 149;
            this.label2.Text = "Kota Tujuan";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(10, 205);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 20);
            this.label1.TabIndex = 147;
            this.label1.Text = "Nama Pemesan";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.IndianRed;
            this.label18.Location = new System.Drawing.Point(10, 420);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 20);
            this.label18.TabIndex = 152;
            this.label18.Text = "Harga";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.IndianRed;
            this.label16.Location = new System.Drawing.Point(210, 248);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 20);
            this.label16.TabIndex = 151;
            this.label16.Text = "Total";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.IndianRed;
            this.label6.Location = new System.Drawing.Point(10, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 20);
            this.label6.TabIndex = 146;
            this.label6.Text = "Tempat Wisata";
            // 
            // txtId
            // 
            this.txtId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtId.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtId.HintForeColor = System.Drawing.Color.Empty;
            this.txtId.HintText = "";
            this.txtId.isPassword = false;
            this.txtId.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtId.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtId.LineThickness = 3;
            this.txtId.Location = new System.Drawing.Point(214, 333);
            this.txtId.Margin = new System.Windows.Forms.Padding(4);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(150, 21);
            this.txtId.TabIndex = 165;
            this.txtId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.IndianRed;
            this.label4.Location = new System.Drawing.Point(210, 303);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 20);
            this.label4.TabIndex = 164;
            this.label4.Text = "ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.IndianRed;
            this.label5.Location = new System.Drawing.Point(404, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 20);
            this.label5.TabIndex = 169;
            this.label5.Text = "Member";
            // 
            // txtCariMember
            // 
            this.txtCariMember.ActiveBorderThickness = 1;
            this.txtCariMember.ActiveCornerRadius = 20;
            this.txtCariMember.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.txtCariMember.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.BackColor = System.Drawing.SystemColors.Control;
            this.txtCariMember.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCariMember.BackgroundImage")));
            this.txtCariMember.ButtonText = "Cari";
            this.txtCariMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtCariMember.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCariMember.ForeColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.IdleBorderThickness = 1;
            this.txtCariMember.IdleCornerRadius = 20;
            this.txtCariMember.IdleFillColor = System.Drawing.Color.White;
            this.txtCariMember.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.txtCariMember.Location = new System.Drawing.Point(770, 202);
            this.txtCariMember.Margin = new System.Windows.Forms.Padding(5);
            this.txtCariMember.Name = "txtCariMember";
            this.txtCariMember.Size = new System.Drawing.Size(89, 35);
            this.txtCariMember.TabIndex = 168;
            this.txtCariMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtIdMember
            // 
            this.txtIdMember.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdMember.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtIdMember.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtIdMember.HintForeColor = System.Drawing.Color.Empty;
            this.txtIdMember.HintText = "";
            this.txtIdMember.isPassword = false;
            this.txtIdMember.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtIdMember.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtIdMember.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtIdMember.LineThickness = 3;
            this.txtIdMember.Location = new System.Drawing.Point(611, 209);
            this.txtIdMember.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdMember.Name = "txtIdMember";
            this.txtIdMember.Size = new System.Drawing.Size(150, 21);
            this.txtIdMember.TabIndex = 167;
            this.txtIdMember.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(408, 237);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(466, 108);
            this.dataGridView2.TabIndex = 166;
            this.dataGridView2.DoubleClick += new System.EventHandler(this.dataGridView2_DoubleClick);
            // 
            // txtEmail
            // 
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmail.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEmail.HintForeColor = System.Drawing.Color.Empty;
            this.txtEmail.HintText = "";
            this.txtEmail.isPassword = false;
            this.txtEmail.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtEmail.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtEmail.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtEmail.LineThickness = 3;
            this.txtEmail.Location = new System.Drawing.Point(696, 355);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(180, 21);
            this.txtEmail.TabIndex = 173;
            this.txtEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.IndianRed;
            this.label8.Location = new System.Drawing.Point(636, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 20);
            this.label8.TabIndex = 172;
            this.label8.Text = "Email";
            // 
            // txtIdMem
            // 
            this.txtIdMem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdMem.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtIdMem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtIdMem.HintForeColor = System.Drawing.Color.Empty;
            this.txtIdMem.HintText = "";
            this.txtIdMem.isPassword = false;
            this.txtIdMem.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtIdMem.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtIdMem.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtIdMem.LineThickness = 3;
            this.txtIdMem.Location = new System.Drawing.Point(510, 356);
            this.txtIdMem.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdMem.Name = "txtIdMem";
            this.txtIdMem.Size = new System.Drawing.Size(107, 21);
            this.txtIdMem.TabIndex = 171;
            this.txtIdMem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.IndianRed;
            this.label7.Location = new System.Drawing.Point(406, 356);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 20);
            this.label7.TabIndex = 170;
            this.label7.Text = "ID Member";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTagihan);
            this.groupBox1.Controls.Add(this.btnKonfirm);
            this.groupBox1.Controls.Add(this.txtKembalian);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.txtUang);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(405, 384);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(466, 126);
            this.groupBox1.TabIndex = 174;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pembayaran";
            // 
            // txtTagihan
            // 
            this.txtTagihan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTagihan.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTagihan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTagihan.HintForeColor = System.Drawing.Color.Empty;
            this.txtTagihan.HintText = "";
            this.txtTagihan.isPassword = false;
            this.txtTagihan.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTagihan.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtTagihan.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTagihan.LineThickness = 3;
            this.txtTagihan.Location = new System.Drawing.Point(39, 48);
            this.txtTagihan.Margin = new System.Windows.Forms.Padding(4);
            this.txtTagihan.Name = "txtTagihan";
            this.txtTagihan.Size = new System.Drawing.Size(126, 21);
            this.txtTagihan.TabIndex = 166;
            this.txtTagihan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTagihan.Leave += new System.EventHandler(this.txtTagihan_Leave);
            // 
            // btnKonfirm
            // 
            this.btnKonfirm.ActiveBorderThickness = 1;
            this.btnKonfirm.ActiveCornerRadius = 20;
            this.btnKonfirm.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.btnKonfirm.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.BackColor = System.Drawing.SystemColors.Control;
            this.btnKonfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKonfirm.BackgroundImage")));
            this.btnKonfirm.ButtonText = "Konfirmasi";
            this.btnKonfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKonfirm.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKonfirm.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.IdleBorderThickness = 1;
            this.btnKonfirm.IdleCornerRadius = 20;
            this.btnKonfirm.IdleFillColor = System.Drawing.Color.White;
            this.btnKonfirm.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnKonfirm.Location = new System.Drawing.Point(286, 74);
            this.btnKonfirm.Margin = new System.Windows.Forms.Padding(5);
            this.btnKonfirm.Name = "btnKonfirm";
            this.btnKonfirm.Size = new System.Drawing.Size(104, 35);
            this.btnKonfirm.TabIndex = 161;
            this.btnKonfirm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnKonfirm.Click += new System.EventHandler(this.btnKonfirm_Click);
            // 
            // txtKembalian
            // 
            this.txtKembalian.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtKembalian.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtKembalian.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtKembalian.HintForeColor = System.Drawing.Color.Empty;
            this.txtKembalian.HintText = "";
            this.txtKembalian.isPassword = false;
            this.txtKembalian.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtKembalian.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtKembalian.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtKembalian.LineThickness = 3;
            this.txtKembalian.Location = new System.Drawing.Point(294, 43);
            this.txtKembalian.Margin = new System.Windows.Forms.Padding(4);
            this.txtKembalian.Name = "txtKembalian";
            this.txtKembalian.Size = new System.Drawing.Size(126, 21);
            this.txtKembalian.TabIndex = 165;
            this.txtKembalian.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.IndianRed;
            this.label19.Location = new System.Drawing.Point(13, 21);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 20);
            this.label19.TabIndex = 167;
            this.label19.Text = "Tagihan";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.IndianRed;
            this.label21.Location = new System.Drawing.Point(10, 48);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(32, 20);
            this.label21.TabIndex = 168;
            this.label21.Text = "Rp";
            // 
            // txtUang
            // 
            this.txtUang.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUang.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtUang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtUang.HintForeColor = System.Drawing.Color.Empty;
            this.txtUang.HintText = "";
            this.txtUang.isPassword = false;
            this.txtUang.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtUang.LineIdleColor = System.Drawing.Color.IndianRed;
            this.txtUang.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtUang.LineThickness = 3;
            this.txtUang.Location = new System.Drawing.Point(32, 100);
            this.txtUang.Margin = new System.Windows.Forms.Padding(4);
            this.txtUang.Name = "txtUang";
            this.txtUang.Size = new System.Drawing.Size(126, 21);
            this.txtUang.TabIndex = 161;
            this.txtUang.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtUang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUang_KeyPress);
            this.txtUang.Leave += new System.EventHandler(this.txtUang_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.IndianRed;
            this.label11.Location = new System.Drawing.Point(268, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 20);
            this.label11.TabIndex = 164;
            this.label11.Text = "Kembalian";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.IndianRed;
            this.label13.Location = new System.Drawing.Point(265, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 20);
            this.label13.TabIndex = 163;
            this.label13.Text = "Rp";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.IndianRed;
            this.label10.Location = new System.Drawing.Point(6, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 20);
            this.label10.TabIndex = 161;
            this.label10.Text = "Uang Yang Dibayarkan";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.IndianRed;
            this.label9.Location = new System.Drawing.Point(3, 100);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 20);
            this.label9.TabIndex = 161;
            this.label9.Text = "Rp";
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(29, 19);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(320, 367);
            this.txtResult.TabIndex = 175;
            this.txtResult.Text = "";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // UiPayTicketWisata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtIdMem);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCariMember);
            this.Controls.Add(this.txtIdMember);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtJml);
            this.Controls.Add(this.txtHarga);
            this.Controls.Add(this.txtTempatWisata);
            this.Controls.Add(this.txtTanggal);
            this.Controls.Add(this.txtKotaTujuan);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnCariTrans);
            this.Controls.Add(this.txtCariIdTrans);
            this.Name = "UiPayTicketWisata";
            this.Size = new System.Drawing.Size(883, 519);
            this.Load += new System.EventHandler(this.UiPayTicketWisata_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnCariTrans;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtCariIdTrans;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTotal;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJml;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtHarga;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTempatWisata;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTanggal;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtKotaTujuan;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtNama;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuThinButton2 txtCariMember;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtIdMember;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtEmail;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtIdMem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTagihan;
        private Bunifu.Framework.UI.BunifuThinButton2 btnKonfirm;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtKembalian;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtUang;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox txtResult;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}
