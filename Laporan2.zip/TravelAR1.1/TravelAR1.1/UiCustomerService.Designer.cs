﻿namespace TravelAR1._1
{
    partial class UiCustomerService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiCustomerService));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.PanelKiri = new System.Windows.Forms.Panel();
            this.btnLogout = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnDroppoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTourguide = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnKendaraan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PanelAtas = new System.Windows.Forms.Panel();
            this.btnclose2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.uiPayMobil1 = new TravelAR1._1.UiPayMobil();
            this.uiPayHotel1 = new TravelAR1._1.UiPayHotel();
            this.uiPayTicketWisata1 = new TravelAR1._1.UiPayTicketWisata();
            this.uiPayTicketBus1 = new TravelAR1._1.UiPayTicketBus();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.PanelKiri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelAtas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose2)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(233, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sistem Informasi - TravelAR";
            // 
            // PanelKiri
            // 
            this.PanelKiri.BackColor = System.Drawing.Color.Salmon;
            this.PanelKiri.Controls.Add(this.btnLogout);
            this.PanelKiri.Controls.Add(this.btnDroppoint);
            this.PanelKiri.Controls.Add(this.btnTourguide);
            this.PanelKiri.Controls.Add(this.bunifuFlatButton1);
            this.PanelKiri.Controls.Add(this.bunifuCustomLabel2);
            this.PanelKiri.Controls.Add(this.btnKendaraan);
            this.PanelKiri.Controls.Add(this.pictureBox1);
            this.PanelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelKiri.Location = new System.Drawing.Point(0, 34);
            this.PanelKiri.Name = "PanelKiri";
            this.PanelKiri.Size = new System.Drawing.Size(235, 519);
            this.PanelKiri.TabIndex = 5;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Salmon;
            this.btnLogout.Image = ((System.Drawing.Image)(resources.GetObject("btnLogout.Image")));
            this.btnLogout.ImageActive = null;
            this.btnLogout.Location = new System.Drawing.Point(193, 480);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(39, 36);
            this.btnLogout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnLogout.TabIndex = 10;
            this.btnLogout.TabStop = false;
            this.btnLogout.Zoom = 10;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnDroppoint
            // 
            this.btnDroppoint.Activecolor = System.Drawing.Color.IndianRed;
            this.btnDroppoint.BackColor = System.Drawing.Color.Salmon;
            this.btnDroppoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDroppoint.BorderRadius = 0;
            this.btnDroppoint.ButtonText = "                   Tiket Wisata";
            this.btnDroppoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDroppoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnDroppoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDroppoint.Iconimage = null;
            this.btnDroppoint.Iconimage_right = null;
            this.btnDroppoint.Iconimage_right_Selected = null;
            this.btnDroppoint.Iconimage_Selected = null;
            this.btnDroppoint.IconMarginLeft = 0;
            this.btnDroppoint.IconMarginRight = 0;
            this.btnDroppoint.IconRightVisible = true;
            this.btnDroppoint.IconRightZoom = 0D;
            this.btnDroppoint.IconVisible = true;
            this.btnDroppoint.IconZoom = 90D;
            this.btnDroppoint.IsTab = true;
            this.btnDroppoint.Location = new System.Drawing.Point(0, 212);
            this.btnDroppoint.Name = "btnDroppoint";
            this.btnDroppoint.Normalcolor = System.Drawing.Color.Salmon;
            this.btnDroppoint.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnDroppoint.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnDroppoint.selected = false;
            this.btnDroppoint.Size = new System.Drawing.Size(235, 29);
            this.btnDroppoint.TabIndex = 5;
            this.btnDroppoint.Text = "                   Tiket Wisata";
            this.btnDroppoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDroppoint.Textcolor = System.Drawing.Color.White;
            this.btnDroppoint.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDroppoint.Click += new System.EventHandler(this.btnDroppoint_Click);
            // 
            // btnTourguide
            // 
            this.btnTourguide.Activecolor = System.Drawing.Color.IndianRed;
            this.btnTourguide.BackColor = System.Drawing.Color.Salmon;
            this.btnTourguide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTourguide.BorderRadius = 0;
            this.btnTourguide.ButtonText = "                   Booking Hotel";
            this.btnTourguide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTourguide.DisabledColor = System.Drawing.Color.Gray;
            this.btnTourguide.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTourguide.Iconimage = null;
            this.btnTourguide.Iconimage_right = null;
            this.btnTourguide.Iconimage_right_Selected = null;
            this.btnTourguide.Iconimage_Selected = null;
            this.btnTourguide.IconMarginLeft = 0;
            this.btnTourguide.IconMarginRight = 0;
            this.btnTourguide.IconRightVisible = true;
            this.btnTourguide.IconRightZoom = 0D;
            this.btnTourguide.IconVisible = true;
            this.btnTourguide.IconZoom = 90D;
            this.btnTourguide.IsTab = true;
            this.btnTourguide.Location = new System.Drawing.Point(0, 282);
            this.btnTourguide.Name = "btnTourguide";
            this.btnTourguide.Normalcolor = System.Drawing.Color.Salmon;
            this.btnTourguide.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnTourguide.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnTourguide.selected = false;
            this.btnTourguide.Size = new System.Drawing.Size(235, 29);
            this.btnTourguide.TabIndex = 4;
            this.btnTourguide.Text = "                   Booking Hotel";
            this.btnTourguide.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTourguide.Textcolor = System.Drawing.Color.White;
            this.btnTourguide.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTourguide.Click += new System.EventHandler(this.btnTourguide_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "                   Rental Mobil";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = true;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 247);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(235, 29);
            this.bunifuFlatButton1.TabIndex = 3;
            this.bunifuFlatButton1.Text = "                   Rental Mobil";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(3, 135);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(149, 25);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "Selamat Datang";
            // 
            // btnKendaraan
            // 
            this.btnKendaraan.Activecolor = System.Drawing.Color.IndianRed;
            this.btnKendaraan.BackColor = System.Drawing.Color.Salmon;
            this.btnKendaraan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKendaraan.BorderRadius = 0;
            this.btnKendaraan.ButtonText = "                   Tiket Bus";
            this.btnKendaraan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKendaraan.DisabledColor = System.Drawing.Color.Gray;
            this.btnKendaraan.Iconcolor = System.Drawing.Color.Transparent;
            this.btnKendaraan.Iconimage = null;
            this.btnKendaraan.Iconimage_right = null;
            this.btnKendaraan.Iconimage_right_Selected = null;
            this.btnKendaraan.Iconimage_Selected = null;
            this.btnKendaraan.IconMarginLeft = 0;
            this.btnKendaraan.IconMarginRight = 0;
            this.btnKendaraan.IconRightVisible = true;
            this.btnKendaraan.IconRightZoom = 0D;
            this.btnKendaraan.IconVisible = true;
            this.btnKendaraan.IconZoom = 90D;
            this.btnKendaraan.IsTab = true;
            this.btnKendaraan.Location = new System.Drawing.Point(0, 177);
            this.btnKendaraan.Name = "btnKendaraan";
            this.btnKendaraan.Normalcolor = System.Drawing.Color.Salmon;
            this.btnKendaraan.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnKendaraan.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnKendaraan.selected = true;
            this.btnKendaraan.Size = new System.Drawing.Size(235, 29);
            this.btnKendaraan.TabIndex = 1;
            this.btnKendaraan.Text = "                   Tiket Bus";
            this.btnKendaraan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKendaraan.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnKendaraan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKendaraan.Click += new System.EventHandler(this.btnKendaraan_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 129);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // PanelAtas
            // 
            this.PanelAtas.BackColor = System.Drawing.Color.LightCoral;
            this.PanelAtas.Controls.Add(this.btnclose2);
            this.PanelAtas.Controls.Add(this.bunifuCustomLabel1);
            this.PanelAtas.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelAtas.Location = new System.Drawing.Point(0, 0);
            this.PanelAtas.Name = "PanelAtas";
            this.PanelAtas.Size = new System.Drawing.Size(1118, 34);
            this.PanelAtas.TabIndex = 6;
            // 
            // btnclose2
            // 
            this.btnclose2.BackColor = System.Drawing.Color.LightCoral;
            this.btnclose2.Image = ((System.Drawing.Image)(resources.GetObject("btnclose2.Image")));
            this.btnclose2.ImageActive = null;
            this.btnclose2.Location = new System.Drawing.Point(1063, 3);
            this.btnclose2.Name = "btnclose2";
            this.btnclose2.Size = new System.Drawing.Size(38, 36);
            this.btnclose2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnclose2.TabIndex = 1;
            this.btnclose2.TabStop = false;
            this.btnclose2.Zoom = 10;
            this.btnclose2.Click += new System.EventHandler(this.btnclose2_Click);
            // 
            // uiPayMobil1
            // 
            this.uiPayMobil1.Location = new System.Drawing.Point(235, 34);
            this.uiPayMobil1.Name = "uiPayMobil1";
            this.uiPayMobil1.Size = new System.Drawing.Size(883, 519);
            this.uiPayMobil1.TabIndex = 10;
            // 
            // uiPayHotel1
            // 
            this.uiPayHotel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.uiPayHotel1.Location = new System.Drawing.Point(235, 34);
            this.uiPayHotel1.Name = "uiPayHotel1";
            this.uiPayHotel1.Size = new System.Drawing.Size(883, 519);
            this.uiPayHotel1.TabIndex = 9;
            // 
            // uiPayTicketWisata1
            // 
            this.uiPayTicketWisata1.Location = new System.Drawing.Point(235, 34);
            this.uiPayTicketWisata1.Name = "uiPayTicketWisata1";
            this.uiPayTicketWisata1.Size = new System.Drawing.Size(883, 519);
            this.uiPayTicketWisata1.TabIndex = 8;
            // 
            // uiPayTicketBus1
            // 
            this.uiPayTicketBus1.BackColor = System.Drawing.Color.White;
            this.uiPayTicketBus1.Location = new System.Drawing.Point(235, 34);
            this.uiPayTicketBus1.Name = "uiPayTicketBus1";
            this.uiPayTicketBus1.Size = new System.Drawing.Size(883, 519);
            this.uiPayTicketBus1.TabIndex = 7;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.PanelAtas;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.PanelAtas;
            this.bunifuDragControl2.Vertical = true;
            // 
            // UiCustomerService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1118, 553);
            this.Controls.Add(this.uiPayMobil1);
            this.Controls.Add(this.uiPayHotel1);
            this.Controls.Add(this.uiPayTicketWisata1);
            this.Controls.Add(this.uiPayTicketBus1);
            this.Controls.Add(this.PanelKiri);
            this.Controls.Add(this.PanelAtas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UiCustomerService";
            this.Text = "UiCustomerService";
            this.PanelKiri.ResumeLayout(false);
            this.PanelKiri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelAtas.ResumeLayout(false);
            this.PanelAtas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel PanelKiri;
        private Bunifu.Framework.UI.BunifuImageButton btnLogout;
        private Bunifu.Framework.UI.BunifuFlatButton btnDroppoint;
        private Bunifu.Framework.UI.BunifuFlatButton btnTourguide;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuFlatButton btnKendaraan;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel PanelAtas;
        private Bunifu.Framework.UI.BunifuImageButton btnclose2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private UiPayTicketBus uiPayTicketBus1;
        private UiPayTicketWisata uiPayTicketWisata1;
        private UiPayHotel uiPayHotel1;
        private UiPayMobil uiPayMobil1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
    }
}