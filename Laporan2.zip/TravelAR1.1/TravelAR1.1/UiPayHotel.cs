﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiPayHotel : UserControl
    {
        public UiPayHotel()
        {
            InitializeComponent();
        }
        private void CekUang()
        {
            if (txtIdMem.Text == "" || txtEmail.Text == "")
            {
                txtTagihan.Text = txtTotal.Text;
            }
            else
            {
                try
                {
                    txtTagihan.Text = (float.Parse(txtTotal.Text) * float.Parse("0.90")).ToString();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error" + Ex);
                }
            }

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtNama.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtKotaTujuan.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtTanggal.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtTempatWisata.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtHarga.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtJml.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtTotal.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            txtTipe.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtId.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            CekUang();
        }
        public void DatagridMember()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmember", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView2.DataSource = dt;
        }

        private void UiPayHotel_Load(object sender, EventArgs e)
        {
            DatagridMember();
            Datagrid();
            txtResult.Hide();
        }

        private void txtUang_Leave(object sender, EventArgs e)
        {
            try
            {
                txtKembalian.Text = (float.Parse(txtUang.Text) - float.Parse(txtTagihan.Text)).ToString();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error" + Ex);
            }
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihattransaksihotel", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["id_transakasi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["nama_pelanggan"].HeaderText = "Nama Pelanggan";
            dataGridView1.Columns["kota"].HeaderText = "Kota";
            dataGridView1.Columns["nama_hotel"].HeaderText = "Nama hOTEL";
            dataGridView1.Columns["tipe_kamar"].HeaderText = "Tipe Kamar";
            dataGridView1.Columns["harga"].HeaderText = "Harga";
            dataGridView1.Columns["jml_kamar"].HeaderText = "Jumlah Kamar";
            dataGridView1.Columns["tgl_pemesanan"].HeaderText = "Tanggal";
            dataGridView1.Columns["durasi"].HeaderText = "Durasi";
            dataGridView1.Columns["total"].HeaderText = "Total";
            dataGridView1.Columns["status"].HeaderText = "Status";

            dataGridView1.Columns[7].DefaultCellStyle.Format = "MM/dd/yyyy";
            dataGridView1.Columns[5].DefaultCellStyle.Format = "Rp #,###.00";
            dataGridView1.Columns[9].DefaultCellStyle.Format = "Rp #,###.00";
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txtIdMem.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtEmail.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
        }

        private void btnKonfirm_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand sqlcmd = new SqlCommand("sp_updatestatushotel", connection);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@status", "Terbayar");
            sqlcmd.Parameters.AddWithValue("@id_transakasi", txtId.Text.Trim());
            sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Pembayaran Berhasil");
            Datagrid();

            txtResult.Clear();
            txtResult.Text += "=====================================================\n";
            txtResult.Text += "====================== TravelAR =======================\n";
            txtResult.Text += "=====================================================\n";
            txtResult.Text += "\n";
            txtResult.Text += "Tanggal Pemesanan\t\t: " + txtTanggal.Text + "\n";
            txtResult.Text += "Nama Pemesan\t\t\t: " + txtNama.Text + "\n";
            txtResult.Text += "Nama Hotel\t\t\t: " + txtTempatWisata.Text + "\n";
            txtResult.Text += "Jumlah Kamar\t\t\t: " + txtJml.Text + "\n";
            txtResult.Text += "\n";
            txtResult.Text += "=====================================================\n";
            txtResult.Text += "Total Pembayaran\t\t: " + txtTagihan.Text + "\n";
            txtResult.Text += "Uang Yang Dibayarkan\t\t: " + txtUang.Text + "\n";
            txtResult.Text += "Kembalian\t\t\t: " + txtKembalian.Text + "\n";
            txtResult.Text += "\n";
            txtResult.Text += "=====================================================\n";

            txtResult.Text += "============= Terimakasih Telah Bertransaksi ===============\n";

            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtResult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }
    }
}
