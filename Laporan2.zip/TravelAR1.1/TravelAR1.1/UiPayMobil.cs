﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiPayMobil : UserControl
    {
        public UiPayMobil()
        {
            InitializeComponent();
        }

        private void UiPayMobil_Load(object sender, EventArgs e)
        {
            DatagridMember();
            Datagrid();
            txtResult.Hide();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtNama.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtKotaTujuan.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtJenis.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtJml.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtHarga.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtTanggal.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtTotal.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtId.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            CekUang();
        }
        private void CekUang()
        {
            if (txtIdMem.Text == "" || txtEmail.Text == "")
            {
                txtTagihan.Text = txtTotal.Text;
            }
            else
            {
                try
                {
                    txtTagihan.Text = (float.Parse(txtTotal.Text) * float.Parse("0.90")).ToString();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error" + Ex);
                }
            }

        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihattransaksimobil", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
           
        }
        public void DatagridMember()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmember", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView2.DataSource = dt;
        }

        private void btnKonfirm_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=LAPTOP-31D7AO7U\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand sqlcmd = new SqlCommand("sp_updatestatusmobil", connection);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@id_transaksi", txtId.Text.Trim());
            sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Pembayaran Berhasil");
            Datagrid();

            txtResult.Clear();
            txtResult.Text += "=====================================================\n";
            txtResult.Text += "====================== TravelAR =======================\n";
            txtResult.Text += "=====================================================\n";
            txtResult.Text += "\n";
            txtResult.Text += "Tanggal Penyewaan\t\t: " + txtTanggal.Text + "\n";
            txtResult.Text += "Nama Pemesan\t\t\t: " + txtNama.Text + "\n";
            txtResult.Text += "Kota Tujuan\t\t\t: " + txtKotaTujuan.Text + "\n";
            txtResult.Text += "Jenis Mobil\t\t\t: " + txtJenis.Text + "\n";
            txtResult.Text += "\n";
            txtResult.Text += "=====================================================\n";
            txtResult.Text += "Total Pembayaran\t\t: " + txtTagihan.Text + "\n";
            txtResult.Text += "Uang Yang Dibayarkan\t\t: " + txtUang.Text + "\n";
            txtResult.Text += "Kembalian\t\t\t: " + txtKembalian.Text + "\n";
            txtResult.Text += "\n";
            txtResult.Text += "=====================================================\n";

            txtResult.Text += "============= Terimakasih Telah Bertransaksi ===============\n";


            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }
    }
}
