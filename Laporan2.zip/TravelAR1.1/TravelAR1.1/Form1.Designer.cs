﻿namespace TravelAR1._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.PanelKiri = new System.Windows.Forms.Panel();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTiketWisata = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTktBus = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PanelAtas = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.btnLogin = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.uiTransHotel1 = new TravelAR1._1.UiTransHotel();
            this.uiTransWisata1 = new TravelAR1._1.UiTransWisata();
            this.uiTransBus1 = new TravelAR1._1.UiTransBus();
            this.uiTransMobil1 = new TravelAR1._1.UiTransMobil();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.PanelKiri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelAtas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // PanelKiri
            // 
            this.PanelKiri.BackColor = System.Drawing.Color.Salmon;
            this.PanelKiri.Controls.Add(this.bunifuFlatButton3);
            this.PanelKiri.Controls.Add(this.bunifuFlatButton2);
            this.PanelKiri.Controls.Add(this.btnTiketWisata);
            this.PanelKiri.Controls.Add(this.btnTktBus);
            this.PanelKiri.Controls.Add(this.pictureBox1);
            this.PanelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelKiri.Location = new System.Drawing.Point(0, 34);
            this.PanelKiri.Name = "PanelKiri";
            this.PanelKiri.Size = new System.Drawing.Size(235, 519);
            this.PanelKiri.TabIndex = 0;
            this.PanelKiri.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelKiri_Paint);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "Penyewaan Mobil";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = true;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(0, 372);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(235, 48);
            this.bunifuFlatButton3.TabIndex = 4;
            this.bunifuFlatButton3.Text = "Penyewaan Mobil";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Pemesanan Hotel";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = true;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(0, 304);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(235, 48);
            this.bunifuFlatButton2.TabIndex = 3;
            this.bunifuFlatButton2.Text = "Pemesanan Hotel";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // btnTiketWisata
            // 
            this.btnTiketWisata.Activecolor = System.Drawing.Color.IndianRed;
            this.btnTiketWisata.BackColor = System.Drawing.Color.Salmon;
            this.btnTiketWisata.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTiketWisata.BorderRadius = 0;
            this.btnTiketWisata.ButtonText = "Pembelian Tiket Wisata";
            this.btnTiketWisata.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTiketWisata.DisabledColor = System.Drawing.Color.Gray;
            this.btnTiketWisata.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTiketWisata.Iconimage = null;
            this.btnTiketWisata.Iconimage_right = null;
            this.btnTiketWisata.Iconimage_right_Selected = null;
            this.btnTiketWisata.Iconimage_Selected = null;
            this.btnTiketWisata.IconMarginLeft = 0;
            this.btnTiketWisata.IconMarginRight = 0;
            this.btnTiketWisata.IconRightVisible = true;
            this.btnTiketWisata.IconRightZoom = 0D;
            this.btnTiketWisata.IconVisible = true;
            this.btnTiketWisata.IconZoom = 90D;
            this.btnTiketWisata.IsTab = true;
            this.btnTiketWisata.Location = new System.Drawing.Point(0, 240);
            this.btnTiketWisata.Name = "btnTiketWisata";
            this.btnTiketWisata.Normalcolor = System.Drawing.Color.Salmon;
            this.btnTiketWisata.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnTiketWisata.OnHoverTextColor = System.Drawing.Color.White;
            this.btnTiketWisata.selected = false;
            this.btnTiketWisata.Size = new System.Drawing.Size(235, 48);
            this.btnTiketWisata.TabIndex = 2;
            this.btnTiketWisata.Text = "Pembelian Tiket Wisata";
            this.btnTiketWisata.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTiketWisata.Textcolor = System.Drawing.Color.White;
            this.btnTiketWisata.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTiketWisata.Click += new System.EventHandler(this.btnTiketWisata_Click);
            // 
            // btnTktBus
            // 
            this.btnTktBus.Activecolor = System.Drawing.Color.IndianRed;
            this.btnTktBus.BackColor = System.Drawing.Color.Salmon;
            this.btnTktBus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTktBus.BorderRadius = 0;
            this.btnTktBus.ButtonText = "Pembelian Tiket Bus";
            this.btnTktBus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTktBus.DisabledColor = System.Drawing.Color.Gray;
            this.btnTktBus.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTktBus.Iconimage = null;
            this.btnTktBus.Iconimage_right = null;
            this.btnTktBus.Iconimage_right_Selected = null;
            this.btnTktBus.Iconimage_Selected = null;
            this.btnTktBus.IconMarginLeft = 0;
            this.btnTktBus.IconMarginRight = 0;
            this.btnTktBus.IconRightVisible = true;
            this.btnTktBus.IconRightZoom = 0D;
            this.btnTktBus.IconVisible = true;
            this.btnTktBus.IconZoom = 90D;
            this.btnTktBus.IsTab = true;
            this.btnTktBus.Location = new System.Drawing.Point(0, 177);
            this.btnTktBus.Name = "btnTktBus";
            this.btnTktBus.Normalcolor = System.Drawing.Color.Salmon;
            this.btnTktBus.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnTktBus.OnHoverTextColor = System.Drawing.Color.White;
            this.btnTktBus.selected = false;
            this.btnTktBus.Size = new System.Drawing.Size(235, 48);
            this.btnTktBus.TabIndex = 1;
            this.btnTktBus.Text = "Pembelian Tiket Bus";
            this.btnTktBus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTktBus.Textcolor = System.Drawing.Color.White;
            this.btnTktBus.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTktBus.Click += new System.EventHandler(this.btnTktBus_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 129);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // PanelAtas
            // 
            this.PanelAtas.BackColor = System.Drawing.Color.LightCoral;
            this.PanelAtas.Controls.Add(this.bunifuImageButton1);
            this.PanelAtas.Controls.Add(this.bunifuCustomLabel1);
            this.PanelAtas.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelAtas.Location = new System.Drawing.Point(0, 0);
            this.PanelAtas.Name = "PanelAtas";
            this.PanelAtas.Size = new System.Drawing.Size(1118, 34);
            this.PanelAtas.TabIndex = 1;
            this.PanelAtas.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelAtas_Paint);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.LightCoral;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1063, 3);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(38, 36);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 1;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(233, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sistem Informasi - TravelAR";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(647, 308);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(110, 20);
            this.txtPassword.TabIndex = 25;
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(647, 259);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(110, 20);
            this.txtUsername.TabIndex = 24;
            // 
            // btnLogin
            // 
            this.btnLogin.ActiveBorderThickness = 1;
            this.btnLogin.ActiveCornerRadius = 20;
            this.btnLogin.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnLogin.ActiveForecolor = System.Drawing.Color.IndianRed;
            this.btnLogin.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnLogin.BackColor = System.Drawing.Color.IndianRed;
            this.btnLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogin.BackgroundImage")));
            this.btnLogin.ButtonText = "Login";
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnLogin.IdleBorderThickness = 1;
            this.btnLogin.IdleCornerRadius = 20;
            this.btnLogin.IdleFillColor = System.Drawing.Color.IndianRed;
            this.btnLogin.IdleForecolor = System.Drawing.Color.DarkRed;
            this.btnLogin.IdleLineColor = System.Drawing.Color.Maroon;
            this.btnLogin.Location = new System.Drawing.Point(566, 366);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(5);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(164, 35);
            this.btnLogin.TabIndex = 23;
            this.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(520, 298);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(104, 30);
            this.bunifuCustomLabel3.TabIndex = 22;
            this.bunifuCustomLabel3.Text = "Password";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(520, 250);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(109, 30);
            this.bunifuCustomLabel2.TabIndex = 21;
            this.bunifuCustomLabel2.Text = "Username";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(605, 191);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(91, 33);
            this.bunifuCustomLabel4.TabIndex = 20;
            this.bunifuCustomLabel4.Text = "Login";
            // 
            // uiTransHotel1
            // 
            this.uiTransHotel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.uiTransHotel1.Location = new System.Drawing.Point(235, 32);
            this.uiTransHotel1.Name = "uiTransHotel1";
            this.uiTransHotel1.Size = new System.Drawing.Size(883, 519);
            this.uiTransHotel1.TabIndex = 28;
            // 
            // uiTransWisata1
            // 
            this.uiTransWisata1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.uiTransWisata1.Location = new System.Drawing.Point(235, 32);
            this.uiTransWisata1.Name = "uiTransWisata1";
            this.uiTransWisata1.Size = new System.Drawing.Size(883, 519);
            this.uiTransWisata1.TabIndex = 27;
            // 
            // uiTransBus1
            // 
            this.uiTransBus1.BackColor = System.Drawing.Color.Silver;
            this.uiTransBus1.Location = new System.Drawing.Point(235, 34);
            this.uiTransBus1.Name = "uiTransBus1";
            this.uiTransBus1.Size = new System.Drawing.Size(883, 519);
            this.uiTransBus1.TabIndex = 26;
            // 
            // uiTransMobil1
            // 
            this.uiTransMobil1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.uiTransMobil1.Location = new System.Drawing.Point(235, 32);
            this.uiTransMobil1.Name = "uiTransMobil1";
            this.uiTransMobil1.Size = new System.Drawing.Size(883, 519);
            this.uiTransMobil1.TabIndex = 29;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.PanelAtas;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.PanelAtas;
            this.bunifuDragControl2.Vertical = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(1118, 553);
            this.Controls.Add(this.uiTransMobil1);
            this.Controls.Add(this.uiTransHotel1);
            this.Controls.Add(this.uiTransWisata1);
            this.Controls.Add(this.uiTransBus1);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.PanelKiri);
            this.Controls.Add(this.PanelAtas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PanelKiri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelAtas.ResumeLayout(false);
            this.PanelAtas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel PanelKiri;
        private Bunifu.Framework.UI.BunifuFlatButton btnTktBus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel PanelAtas;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton btnTiketWisata;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private Bunifu.Framework.UI.BunifuThinButton2 btnLogin;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private UiTransBus uiTransBus1;
        private UiTransWisata uiTransWisata1;
        private UiTransHotel uiTransHotel1;
        private UiTransMobil uiTransMobil1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
    }
}

