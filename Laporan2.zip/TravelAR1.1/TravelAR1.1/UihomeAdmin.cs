﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelAR1._1
{
    public partial class UihomeAdmin : Form
    {
        public UihomeAdmin()
        {
            InitializeComponent();
        }

        private void PanelAtas_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PanelKiri_Paint(object sender, PaintEventArgs e)
        {

        }

        private void uiHome1_Load(object sender, EventArgs e)
        {
           
        }

        private void btnclose2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnKendaraan_Click(object sender, EventArgs e)
        {
            uiKendaraan1.Show();
            uiTempatwisata1.Hide();
            uiDroppoint1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            uiTempatwisata1.Show();
            uiKendaraan1.Hide();
            uiDroppoint1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();

        }

        private void UihomeAdmin_Load(object sender, EventArgs e)
        {
            uiKendaraan1.Show();
            uiTempatwisata1.Hide();
            uiDroppoint1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();
            //kendaraancariupdate1.Show();
        }

        private void btnDroppoint_Click(object sender, EventArgs e)
        {
            uiDroppoint1.Show();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();
        }

        private void btnTourguide_Click(object sender, EventArgs e)
        {
            uiDroppoint1.Hide();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Show();
            uiMobil1.Hide();
            uiJadwal1.Hide();
        }

        private void btnHotel_Click(object sender, EventArgs e)
        {
            uiDroppoint1.Hide();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Show();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();
        }

        private void btnMobil_Click(object sender, EventArgs e)
        {
            uiDroppoint1.Hide();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Show();
            uiJadwal1.Hide();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            uiDroppoint1.Hide();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Show();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();
        }

        private void btnKaryawan_Click(object sender, EventArgs e)
        {
            uiDroppoint1.Hide();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Show();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
            uiJadwal1.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();

        }

        private void btnJadwal_Click(object sender, EventArgs e)
        {
            uiJadwal1.Show();
            uiDroppoint1.Hide();
            uiKendaraan1.Hide();
            uiTempatwisata1.Hide();
            uiHotel1.Hide();
            uiKaryawan1.Hide();
            uiMember1.Hide();
            uiTourguide1.Hide();
            uiMobil1.Hide();
        }
    }
}
