﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DGVPrinterHelper;

namespace TravelAR1._1
{
    public partial class UiLapWisata : UserControl
    {
        public UiLapWisata()
        {
            InitializeComponent();
        }
        SqlCommand sqlCmd;

        private void UiLapWisata_Load(object sender, EventArgs e)
        {
            Tampilcmbnama();
        }
        public void Tampilcmbnama()
        {
           cmbFilter.Items.Clear();
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            sqlCmd = connection.CreateCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "SELECT nama FROM ms_wisata";
            sqlCmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                cmbFilter.Items.Add(dr["nama"].ToString());
            }
            connection.Close();

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_laporanwisata", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            mycmd.Parameters.AddWithValue("@date1", dtTanggal1.Value.Date.ToShortDateString());
            mycmd.Parameters.AddWithValue("@date2", dtTanggal2.Value.Date.ToShortDateString());
            mycmd.Parameters.AddWithValue("@nama", cmbFilter.Text);
            mycmd.Parameters.AddWithValue("@status", "Terbayar");

            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            //Datagrid1();
            dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
            dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
            dataGridView1.Columns["nama_wisata"].HeaderText = "Nama Wisata";
            dataGridView1.Columns["total"].HeaderText = "Total Harga";
            dataGridView1.Columns[4].DefaultCellStyle.Format = "Rp #,###.00";
            HitungUang();
        }
        private void HitungUang()
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[4].Value);
            }
            //double t = sum;
            //int total = Convert.ToInt32(t);
            lblUang.Text = sum.ToString();
            lbluangwisata.Text = (float.Parse(lblUang.Text) * float.Parse("0.80")).ToString();
            lblpendapatan.Text = (float.Parse(lblUang.Text) - float.Parse(lbluangwisata.Text)).ToString();

        }

        private void btnCetak_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter();
            printer.Title = "Laporan Transaksi Penjualan Tiket Wisata " + cmbFilter.Text +"";
            printer.SubTitle = "Periode  " + dtTanggal1.Value.Date.ToShortDateString() + " Sampai Dengan  " + dtTanggal2.Value.Date.ToShortDateString() + "";
            printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            printer.PageNumbers = true;

            printer.PageNumberInHeader = false;

            printer.PorportionalColumns = true;

            printer.HeaderCellAlignment = StringAlignment.Near;

            printer.Footer = "Total Pendapatan Rp  " + lblpendapatan.Text + "";

            printer.FooterSpacing = 10;



            printer.PrintDataGridView(dataGridView1);
        }
    }
}
