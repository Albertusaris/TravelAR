﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class droppointcariupdate : UserControl
    {
        public droppointcariupdate()
        {
            InitializeComponent();
        }

        private void droppointcariupdate_Load(object sender, EventArgs e)
        {
            Datagrid();
            txtIddroppoint.Visible = true;
            txtKota.Visible = true;
            txtNama.Visible = true;
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatdroppoint", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtIddroppoint.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtKota.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtNama.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtIddroppoint.Text == "" || txtKota.Text == "" || txtNama.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletedroppoint", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id_droppoint", txtIddroppoint.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    Reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
                
        }
        private void Reset()
        {
            txtIddroppoint.Text = "";
            txtKota.Text = "";
            txtNama.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtIddroppoint.Text == "" || txtKota.Text == "" || txtNama.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatedroppoint", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@nama", txtNama.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@id_droppoint", txtIddroppoint.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil DiUpdate!");
                Reset();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }
    }
}
