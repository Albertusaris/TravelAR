﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DGVPrinterHelper;

namespace TravelAR1._1
{
    public partial class UiLapBus : UserControl
    {
        public UiLapBus()
        {
            InitializeComponent();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_laporanbus", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            mycmd.Parameters.AddWithValue("@date1", dtTanggal1.Value.Date.ToShortDateString());
            mycmd.Parameters.AddWithValue("@date2", dtTanggal2.Value.Date.ToShortDateString());
            mycmd.Parameters.AddWithValue("@status", "Terbayar");

            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            //Datagrid1();
            dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
            dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
            dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
            dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
            dataGridView1.Columns["jenis"].HeaderText = "Jenis Kendaraan";
            dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
            dataGridView1.Columns["total"].HeaderText = "Total Harga";
            dataGridView1.Columns[6].DefaultCellStyle.Format = "Rp #,###.00";
            HitungUang();
        }

        private void UiLapBus_Load(object sender, EventArgs e)
        {
          
        }
        private void HitungUang()
        {
            int sum = 0;
            for(int i = 0; i < dataGridView1.Rows.Count;i++)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[6].Value);
            }
            //double t = sum;
            //int total = Convert.ToInt32(t);
            lblUang.Text = sum.ToString();

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (txtCari.Text != "")
            {

                if (cmbFilter.Text == "Kota Asal")
                {
                    DGVPrinter printer = new DGVPrinter();
                    printer.Title = "Laporan Transaksi Penjualan Tiket Bus";
                    printer.SubTitle = "Dengan Kota Asal  " + txtCari.Text + "";
                    printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
                    printer.PageNumbers = true;

                    printer.PageNumberInHeader = false;

                    printer.PorportionalColumns = true;

                    printer.HeaderCellAlignment = StringAlignment.Near;

                    printer.Footer = "Total Pendapatan Rp  " + lblUang.Text + "";

                    printer.FooterSpacing = 10;
                    printer.PrintDataGridView(dataGridView1);
                }
                else if (cmbFilter.Text == "Kota Tujuan")
                {
                    DGVPrinter printer = new DGVPrinter();
                    printer.Title = "Laporan Transaksi Penjualan Tiket Bus";
                    printer.SubTitle = "Dengan Kota Tujan  " + txtCari.Text + "";
                    printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
                    printer.PageNumbers = true;

                    printer.PageNumberInHeader = false;

                    printer.PorportionalColumns = true;

                    printer.HeaderCellAlignment = StringAlignment.Near;

                    printer.Footer = "Total Pendapatan Rp  " + lblUang.Text + "";

                    printer.FooterSpacing = 10;
                    printer.PrintDataGridView(dataGridView1);
                }
                else if (cmbFilter.Text == "No Plat")
                {
                    DGVPrinter printer = new DGVPrinter();
                    printer.Title = "Laporan Transaksi Penjualan Tiket Bus";
                    printer.SubTitle = "Dengan No Plat Kendaraan  " + txtCari.Text + "";
                    printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
                    printer.PageNumbers = true;

                    printer.PageNumberInHeader = false;

                    printer.PorportionalColumns = true;

                    printer.HeaderCellAlignment = StringAlignment.Near;

                    printer.Footer = "Total Pendapatan Rp  " + lblUang.Text + "";

                    printer.FooterSpacing = 10;
                    printer.PrintDataGridView(dataGridView1);
                }
                else
                {
                    MessageBox.Show("Error");
                }

            }
            else
            {
                DGVPrinter printer = new DGVPrinter();
                printer.Title = "Laporan Transaksi Penjualan Tiket Bus";
                printer.SubTitle = "Periode  " + dtTanggal1.Value.Date.ToShortDateString() + " Sampai Dengan  " + dtTanggal2.Value.Date.ToShortDateString() + "";
                printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
                printer.PageNumbers = true;

                printer.PageNumberInHeader = false;

                printer.PorportionalColumns = true;

                printer.HeaderCellAlignment = StringAlignment.Near;

                printer.Footer = "Total Pendapatan Rp  " + lblUang.Text + "";

                printer.FooterSpacing = 10;



                printer.PrintDataGridView(dataGridView1);
            }
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            if (cmbFilter.Text == "Kota Asal")
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand mycmd = new SqlCommand("sp_carilaporanbuskotaasal", connection);
                    mycmd.CommandType = CommandType.StoredProcedure;
                    mycmd.Parameters.AddWithValue("@kota_asal", txtCari.Text);
                    mycmd.Parameters.AddWithValue("@status", "Terbayar");

                    DataTable dt = new DataTable();
                    dt.Load(mycmd.ExecuteReader());
                    dataGridView1.DataSource = dt;
                    //Datagrid1();
                    dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
                    dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
                    dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
                    dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
                    dataGridView1.Columns["jenis"].HeaderText = "Jenis Kendaraan";
                    dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
                    dataGridView1.Columns["total"].HeaderText = "Total Harga";
                    dataGridView1.Columns[6].DefaultCellStyle.Format = "Rp #,###.00";
                    HitungUang();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Data Tidak Ditemukan" + Ex);
                }

            }
            else if (cmbFilter.Text == "Kota Tujuan")
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand mycmd = new SqlCommand("sp_carilaporanbuskotatujuan", connection);
                    mycmd.CommandType = CommandType.StoredProcedure;
                    mycmd.Parameters.AddWithValue("@kota_tujuan", txtCari.Text);
                    mycmd.Parameters.AddWithValue("@status", "Terbayar");

                    DataTable dt = new DataTable();
                    dt.Load(mycmd.ExecuteReader());
                    dataGridView1.DataSource = dt;
                    //Datagrid1();
                    dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
                    dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
                    dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
                    dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
                    dataGridView1.Columns["jenis"].HeaderText = "Jenis Kendaraan";
                    dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
                    dataGridView1.Columns["total"].HeaderText = "Total Harga";
                    HitungUang();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Data Tidak Ditemukan" + Ex);
                }
            }
            else if (cmbFilter.Text == "No Plat") 
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand mycmd = new SqlCommand("sp_carilaporanbusnoplat", connection);
                    mycmd.CommandType = CommandType.StoredProcedure;
                    mycmd.Parameters.AddWithValue("@noplat", txtCari.Text);
                    mycmd.Parameters.AddWithValue("@status", "Terbayar");

                    DataTable dt = new DataTable();
                    dt.Load(mycmd.ExecuteReader());
                    dataGridView1.DataSource = dt;
                    //Datagrid1();
                    dataGridView1.Columns["id_transaksi"].HeaderText = "ID Transaksi";
                    dataGridView1.Columns["kota_asal"].HeaderText = "Kota Asal";
                    dataGridView1.Columns["kota_tujuan"].HeaderText = "Kota Tujuan";
                    dataGridView1.Columns["tanggal"].HeaderText = "Tanggal";
                    dataGridView1.Columns["jenis"].HeaderText = "Jenis Kendaraan";
                    dataGridView1.Columns["no_plat"].HeaderText = "No Plat";
                    dataGridView1.Columns["total"].HeaderText = "Total Harga";
                    HitungUang();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Data Tidak Ditemukan" + Ex);
                }
            }
            else
            {
                MessageBox.Show("Pilih Filter Terlebih Dahulu");
            }
        }
    }
    }

