﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiKendaraan : UserControl
    {
        public UiKendaraan()
        {
            InitializeComponent();
            string query = "select top 1 id_kendaraan from ms_kendaraan order by id_kendaraan desc";
            txtIdKendaraan.Text = autogenerateID("BS", query);

        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
            SqlConnection connection = new SqlConnection(connectionstring);

            SqlCommand insert = new SqlCommand("sp_inputkendaraan", connection);
            insert.CommandType = CommandType.StoredProcedure;

            insert.Parameters.AddWithValue("id_kendaraan", txtIdKendaraan.Text);
            insert.Parameters.AddWithValue("jenis", cmbJenis.Text);
            insert.Parameters.AddWithValue("kapasitas", txtKapasitas.Text);
            insert.Parameters.AddWithValue("kota_asal", cmbKotaasal.Text);
            insert.Parameters.AddWithValue("kota_tujuan", cmbKotatujuan.Text);
            insert.Parameters.AddWithValue("harga", txtHarga.Text);

            try
            {
                connection.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data Belum Tersimpan " + ex.Message);

            }
        }

        private void UiKendaraan_Load(object sender, EventArgs e)
        {
            Datagrid();
            TampilcmbKapasitas();
            Tampilcmbkota();

        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatkendaraan", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }
        public void TampilcmbKapasitas()
        {
            cmbJenis.Items.Clear();
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            sqlCmd = connection.CreateCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "SELECT jenis FROM kapasitas";
            sqlCmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                cmbJenis.Items.Add(dr["jenis"].ToString());
            }
            connection.Close();
           
        }

        private void cmbJenis_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlCommand mycmd = new SqlCommand("SELECT * FROM kapasitas WHERE jenis = '" + cmbJenis.Text + "'", connection);
            connection.Open();
            mycmd.ExecuteNonQuery();
            SqlDataReader dr;
            dr = mycmd.ExecuteReader();
            while (dr.Read())
            {
                string kapasitas = (string)dr["kapasitas"].ToString();
                txtKapasitas.Text = kapasitas;

            }
            connection.Close();
        }
        private void Tampilcmbkota()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT asal FROM tb_tempat", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKotaasal.Items.Clear();
            foreach(DataRow ROW in dt.Rows)
            {
                cmbKotaasal.Items.Add(ROW["asal"].ToString());
            }
        }

        private void cmbKotaasal_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT tujuan FROM tb_tempat WHERE asal = '"+cmbKotaasal.Text+"'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKotatujuan.Items.Clear();
            foreach(DataRow AB in dt.Rows)
            {
                cmbKotatujuan.Items.Add(AB["tujuan"].ToString());
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            txtIdKendaraan.Text = "";
            cmbJenis.Text = "";
            txtKapasitas.Text = "";
            cmbKotaasal.Text = "";
            cmbKotatujuan.Text = "";
            txtHarga.Text = "";
            string query = "select top 1 id_kendaraan from ms_kendaraan order by id_kendaraan desc";
            txtIdKendaraan.Text = autogenerateID("BS", query);

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }
    }
}
