﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiKaryawan : UserControl
    {
        public UiKaryawan()
        {
            InitializeComponent();
            string query = "select top 1 id_karyawan from ms_karyawan order by id_karyawan desc";
            txtIdKaryawan.Text = autogenerateID("KR", query);

        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void UiKaryawan_Load(object sender, EventArgs e)
        {
            Datagrid();
            btnKembali.Hide();
            karyawancariupdate1.Hide();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (txtNama.Text == "" || txtNik.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "" || txtUsername.Text == "" || txtPass.Text =="")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
                SqlConnection connection = new SqlConnection(connectionstring);

                SqlCommand insert = new SqlCommand("sp_inputkaryawan", connection);
                insert.CommandType = CommandType.StoredProcedure;

                insert.Parameters.AddWithValue("id_karyawan", txtIdKaryawan.Text);
                insert.Parameters.AddWithValue("nama", txtNama.Text);
                insert.Parameters.AddWithValue("nik", txtNik.Text);
                insert.Parameters.AddWithValue("email", txtEmail.Text);
                insert.Parameters.AddWithValue("no_telp", txtNotelp.Text);
                insert.Parameters.AddWithValue("username", txtUsername.Text);
                insert.Parameters.AddWithValue("password", txtPass.Text);

                try
                {
                    connection.Open();
                    insert.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data Belum Tersimpan " + ex.Message);

                }
            }
                
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatkaryawan", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void btnBersihkan_Click(object sender, EventArgs e)
        {
            txtIdKaryawan.Text = "";
            txtNama.Text = "";
            txtNik.Text = "";
            txtEmail.Text = "";
            txtNotelp.Text = "";
            txtUsername.Text = "";
            txtPass.Text = "";
            string query = "select top 1 id_karyawan from ms_karyawan order by id_karyawan desc";
            txtIdKaryawan.Text = autogenerateID("KR", query);

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            btnKembali.Show();
            karyawancariupdate1.Show();
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            btnKembali.Hide();
            karyawancariupdate1.Hide();
        }

        private void txtNik_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtNotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
