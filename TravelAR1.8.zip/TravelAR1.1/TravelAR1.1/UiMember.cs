﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiMember : UserControl
    {
        public UiMember()
        {
            InitializeComponent();
            string query = "select top 1 id_member from ms_member order by id_member desc";
            txtIdmember.Text = autogenerateID("MS", query);
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmember", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void UiMember_Load(object sender, EventArgs e)
        {
            membercariupdate1.Hide();
            Datagrid();
            btnKembali.Hide();
            membercariupdate1.Hide();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
            SqlConnection connection = new SqlConnection(connectionstring);

            SqlCommand insert = new SqlCommand("sp_inputmember", connection);
            insert.CommandType = CommandType.StoredProcedure;

            insert.Parameters.AddWithValue("id_member", txtIdmember.Text);
            insert.Parameters.AddWithValue("nama", txtNama.Text);
            insert.Parameters.AddWithValue("nik", txtNik.Text);
            insert.Parameters.AddWithValue("email", txtEmail.Text);
            insert.Parameters.AddWithValue("no_ktp", txtNotelp.Text);

            try
            {
                connection.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data Belum Tersimpan " + ex.Message);

            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnSimpan_Click_1(object sender, EventArgs e)
        {
            if (txtIdmember.Text == "" || txtNama.Text == "" || txtNik.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
                SqlConnection connection = new SqlConnection(connectionstring);

                SqlCommand insert = new SqlCommand("sp_inputmember", connection);
                insert.CommandType = CommandType.StoredProcedure;

                insert.Parameters.AddWithValue("id_member", txtIdmember.Text);
                insert.Parameters.AddWithValue("nama", txtNama.Text);
                insert.Parameters.AddWithValue("nik", txtNik.Text);
                insert.Parameters.AddWithValue("email", txtEmail.Text);
                insert.Parameters.AddWithValue("no_telp", txtNotelp.Text);

                try
                {
                    connection.Open();
                    insert.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data Belum Tersimpan " + ex.Message);

                }
            }
                
        }

        private void btnRefresh_Click_1(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            membercariupdate1.Hide();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            membercariupdate1.Show();
            btnKembali.Show();
        }

        private void btnKembali_Click_1(object sender, EventArgs e)
        {
            btnKembali.Hide();
            membercariupdate1.Hide();
        }

        private void txtNama_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtNik_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtNotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
