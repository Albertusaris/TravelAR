﻿namespace TravelAR1._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.PanelKiri = new System.Windows.Forms.Panel();
            this.btnTktBus = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PanelAtas = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.uiHome1 = new TravelAR1._1.UiHome();
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.PanelKiri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelAtas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // PanelKiri
            // 
            this.PanelKiri.BackColor = System.Drawing.Color.Salmon;
            this.PanelKiri.Controls.Add(this.btnTktBus);
            this.PanelKiri.Controls.Add(this.pictureBox1);
            this.PanelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelKiri.Location = new System.Drawing.Point(0, 34);
            this.PanelKiri.Name = "PanelKiri";
            this.PanelKiri.Size = new System.Drawing.Size(235, 519);
            this.PanelKiri.TabIndex = 0;
            // 
            // btnTktBus
            // 
            this.btnTktBus.Activecolor = System.Drawing.Color.IndianRed;
            this.btnTktBus.BackColor = System.Drawing.Color.Salmon;
            this.btnTktBus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTktBus.BorderRadius = 0;
            this.btnTktBus.ButtonText = "Pembelian Tiket Bus";
            this.btnTktBus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTktBus.DisabledColor = System.Drawing.Color.Gray;
            this.btnTktBus.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTktBus.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnTktBus.Iconimage")));
            this.btnTktBus.Iconimage_right = null;
            this.btnTktBus.Iconimage_right_Selected = null;
            this.btnTktBus.Iconimage_Selected = null;
            this.btnTktBus.IconMarginLeft = 0;
            this.btnTktBus.IconMarginRight = 0;
            this.btnTktBus.IconRightVisible = true;
            this.btnTktBus.IconRightZoom = 0D;
            this.btnTktBus.IconVisible = true;
            this.btnTktBus.IconZoom = 90D;
            this.btnTktBus.IsTab = false;
            this.btnTktBus.Location = new System.Drawing.Point(0, 177);
            this.btnTktBus.Name = "btnTktBus";
            this.btnTktBus.Normalcolor = System.Drawing.Color.Salmon;
            this.btnTktBus.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnTktBus.OnHoverTextColor = System.Drawing.Color.White;
            this.btnTktBus.selected = false;
            this.btnTktBus.Size = new System.Drawing.Size(235, 48);
            this.btnTktBus.TabIndex = 1;
            this.btnTktBus.Text = "Pembelian Tiket Bus";
            this.btnTktBus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTktBus.Textcolor = System.Drawing.Color.White;
            this.btnTktBus.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 129);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // PanelAtas
            // 
            this.PanelAtas.BackColor = System.Drawing.Color.LightCoral;
            this.PanelAtas.Controls.Add(this.bunifuImageButton1);
            this.PanelAtas.Controls.Add(this.bunifuCustomLabel1);
            this.PanelAtas.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelAtas.Location = new System.Drawing.Point(0, 0);
            this.PanelAtas.Name = "PanelAtas";
            this.PanelAtas.Size = new System.Drawing.Size(1118, 34);
            this.PanelAtas.TabIndex = 1;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.LightCoral;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1063, 3);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(38, 36);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 1;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(233, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sistem Informasi - TravelAR";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.PanelAtas;
            this.bunifuDragControl1.Vertical = true;
            // 
            // uiHome1
            // 
            this.uiHome1.BackColor = System.Drawing.Color.IndianRed;
            this.uiHome1.Location = new System.Drawing.Point(235, 34);
            this.uiHome1.Name = "uiHome1";
            this.uiHome1.Size = new System.Drawing.Size(883, 519);
            this.uiHome1.TabIndex = 2;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.uiHome1;
            this.bunifuDragControl2.Vertical = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(1118, 553);
            this.Controls.Add(this.uiHome1);
            this.Controls.Add(this.PanelKiri);
            this.Controls.Add(this.PanelAtas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PanelKiri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelAtas.ResumeLayout(false);
            this.PanelAtas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel PanelKiri;
        private Bunifu.Framework.UI.BunifuFlatButton btnTktBus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel PanelAtas;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private UiHome uiHome1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
    }
}

