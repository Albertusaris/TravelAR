﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class tourguidecariupdate : UserControl
    {
        public tourguidecariupdate()
        {
            InitializeComponent();
        }

        private void tourguidecariupdate_Load(object sender, EventArgs e)
        {
            Datagrid();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihattourguide", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtIdtourguide.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtKota.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtnama.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtEmail.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtNotelp.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtKota.Text == "" || txtnama.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatetourguide", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@no_telp", txtNotelp.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@id_tourguide", txtIdtourguide.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil DiUpdate!");
                Reset();
            }
               
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtKota.Text == "" || txtnama.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletetourguide", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id_tourguide", txtIdtourguide.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    Reset();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
               
        }
        private void Reset()
        {
            txtIdtourguide.Text = "";
            txtKota.Text = "";
            txtnama.Text = "";
            txtEmail.Text = "";
            txtNotelp.Text = "";
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void txtNotelp_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
