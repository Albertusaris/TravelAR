﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class Uiloginadm : UserControl
    {
        public Uiloginadm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True";
            con.Open();
            string userid = txtUsername.Text;
            string password = txtPassword.Text;
            SqlCommand cmd = new SqlCommand("select username,password from tb_admin where username='" + txtUsername.Text + "'and password='" + txtPassword.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
              
                MessageBox.Show("Login Berhasil sebagai admin");
                UihomeAdmin adm = new UihomeAdmin();
                adm.Show();
                Form1 form = new Form1();
                form.Close();
                
                


            }
            else 
            {
                MessageBox.Show("Gagal Login, Username atau Password Salah!");
            }
            con.Close();
        }
    }
}
