﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelAR1._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uiHome1.Show();
        }

        private void uiHome1_Load(object sender, EventArgs e)
        {

        }

        private void PanelKiri_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            uiHome1.Show();
            uiloginadm1.Hide();
            uilogincs1.Hide();
            uiloginmanager1.Hide();
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            uiHome1.Hide();
            uiloginadm1.Show();
            uilogincs1.Hide();
            uiloginmanager1.Hide();
        }

        private void btnCs_Click(object sender, EventArgs e)
        {
            uiHome1.Hide();
            uiloginadm1.Hide();
            uilogincs1.Show();
            uiloginmanager1.Hide();
        }

        private void btnManager_Click(object sender, EventArgs e)
        {
            uiHome1.Hide();
            uiloginadm1.Hide();
            uilogincs1.Hide();
            uiloginmanager1.Show();
        }
    }
}
