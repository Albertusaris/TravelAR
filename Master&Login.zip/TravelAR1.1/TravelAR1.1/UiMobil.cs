﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class UiMobil : UserControl
    {
        public UiMobil()
        {
            InitializeComponent();
            string query = "select top 1 id_mobil from ms_mobil order by id_mobil desc";
            txtIdmobil.Text = autogenerateID("MB", query);
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";

        private void UiMobil_Load(object sender, EventArgs e)
        {
            Datagrid();
            Tampilcmbjenis();
            mobilcariupdate1.Hide();
            btnKembali.Hide();
        }
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }
        public void Tampilcmbjenis()
        {
            cmbjenis.Items.Clear();
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            sqlCmd = connection.CreateCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "SELECT jenis FROM tb_jenismobil";
            sqlCmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                cmbjenis.Items.Add(dr["jenis"].ToString());
            }
            connection.Close();
        }

        private void cmbjenis_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlCommand mycmd = new SqlCommand("SELECT * FROM tb_jenismobil WHERE jenis = '" + cmbjenis.Text + "'", connection);
            connection.Open();
            mycmd.ExecuteNonQuery();
            SqlDataReader dr;
            dr = mycmd.ExecuteReader();
            while (dr.Read())
            {
                string penumpang = (string)dr["jml_penumpang"].ToString();
                txtPenumpang.Text = penumpang;

            }
            connection.Close();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmobil", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (txtIdmobil.Text == "" || cmbjenis.Text == "" || txtPenumpang.Text == "" || txtJmlmobil.Text == "" || txtHarga.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
                SqlConnection connection = new SqlConnection(connectionstring);

                SqlCommand insert = new SqlCommand("sp_inputmobil", connection);
                insert.CommandType = CommandType.StoredProcedure;

                insert.Parameters.AddWithValue("id_mobil", txtIdmobil.Text);
                insert.Parameters.AddWithValue("jenis", cmbjenis.Text);
                insert.Parameters.AddWithValue("jml_penumpang", txtPenumpang.Text);
                insert.Parameters.AddWithValue("jml_mobil", txtJmlmobil.Text);
                insert.Parameters.AddWithValue("harga", txtHarga.Text);

                try
                {
                    connection.Open();
                    insert.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data Belum Tersimpan " + ex.Message);

                }
            }
                
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            txtIdmobil.Text = "";
            cmbjenis.Text = "";
            txtPenumpang.Text = "";
            txtJmlmobil.Text = "";
            txtHarga.Text = "";
            string query = "select top 1 id_mobil from ms_mobil order by id_mobil desc";
            txtIdmobil.Text = autogenerateID("MB", query);
        }

        private void btnHapus2_Click(object sender, EventArgs e)
        {
            mobilcariupdate1.Show();
            btnKembali.Show();
        }

        private void btnkembali_Click(object sender, EventArgs e)
        {
            mobilcariupdate1.Hide();
        }

        private void btnKembali_Click_1(object sender, EventArgs e)
        {
            mobilcariupdate1.Hide();
            btnKembali.Hide();
        }

        private void txtPenumpang_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtJmlmobil_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtHarga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
