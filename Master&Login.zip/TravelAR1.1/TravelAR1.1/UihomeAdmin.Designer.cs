﻿namespace TravelAR1._1
{
    partial class UihomeAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UihomeAdmin));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.PanelAtas = new System.Windows.Forms.Panel();
            this.btnclose2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnKendaraan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTourguide = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDroppoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnHotel = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnMobil = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnMember = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnKaryawan = new Bunifu.Framework.UI.BunifuFlatButton();
            this.PanelKiri = new System.Windows.Forms.Panel();
            this.uiKaryawan1 = new TravelAR1._1.UiKaryawan();
            this.uiMember1 = new TravelAR1._1.UiMember();
            this.uiMobil1 = new TravelAR1._1.UiMobil();
            this.uiHotel1 = new TravelAR1._1.UiHotel();
            this.uiTourguide1 = new TravelAR1._1.UiTourguide();
            this.uiDroppoint1 = new TravelAR1._1.UiDroppoint();
            this.uiTempatwisata1 = new TravelAR1._1.UiTempatwisata();
            this.uiKendaraan1 = new TravelAR1._1.UiKendaraan();
            this.bunifuDragControl5 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.btnLogout = new Bunifu.Framework.UI.BunifuImageButton();
            this.PanelAtas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelKiri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogout)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // PanelAtas
            // 
            this.PanelAtas.BackColor = System.Drawing.Color.LightCoral;
            this.PanelAtas.Controls.Add(this.btnclose2);
            this.PanelAtas.Controls.Add(this.bunifuCustomLabel1);
            this.PanelAtas.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelAtas.Location = new System.Drawing.Point(0, 0);
            this.PanelAtas.Name = "PanelAtas";
            this.PanelAtas.Size = new System.Drawing.Size(1118, 34);
            this.PanelAtas.TabIndex = 4;
            this.PanelAtas.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelAtas_Paint);
            // 
            // btnclose2
            // 
            this.btnclose2.BackColor = System.Drawing.Color.LightCoral;
            this.btnclose2.Image = ((System.Drawing.Image)(resources.GetObject("btnclose2.Image")));
            this.btnclose2.ImageActive = null;
            this.btnclose2.Location = new System.Drawing.Point(1063, 3);
            this.btnclose2.Name = "btnclose2";
            this.btnclose2.Size = new System.Drawing.Size(38, 36);
            this.btnclose2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnclose2.TabIndex = 1;
            this.btnclose2.TabStop = false;
            this.btnclose2.Zoom = 10;
            this.btnclose2.Click += new System.EventHandler(this.btnclose2_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(233, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sistem Informasi - TravelAR";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 129);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnKendaraan
            // 
            this.btnKendaraan.Activecolor = System.Drawing.Color.IndianRed;
            this.btnKendaraan.BackColor = System.Drawing.Color.Salmon;
            this.btnKendaraan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKendaraan.BorderRadius = 0;
            this.btnKendaraan.ButtonText = "                   Kendaraan";
            this.btnKendaraan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKendaraan.DisabledColor = System.Drawing.Color.Gray;
            this.btnKendaraan.Iconcolor = System.Drawing.Color.Transparent;
            this.btnKendaraan.Iconimage = null;
            this.btnKendaraan.Iconimage_right = null;
            this.btnKendaraan.Iconimage_right_Selected = null;
            this.btnKendaraan.Iconimage_Selected = null;
            this.btnKendaraan.IconMarginLeft = 0;
            this.btnKendaraan.IconMarginRight = 0;
            this.btnKendaraan.IconRightVisible = true;
            this.btnKendaraan.IconRightZoom = 0D;
            this.btnKendaraan.IconVisible = true;
            this.btnKendaraan.IconZoom = 90D;
            this.btnKendaraan.IsTab = true;
            this.btnKendaraan.Location = new System.Drawing.Point(0, 177);
            this.btnKendaraan.Name = "btnKendaraan";
            this.btnKendaraan.Normalcolor = System.Drawing.Color.Salmon;
            this.btnKendaraan.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnKendaraan.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnKendaraan.selected = true;
            this.btnKendaraan.Size = new System.Drawing.Size(235, 29);
            this.btnKendaraan.TabIndex = 1;
            this.btnKendaraan.Text = "                   Kendaraan";
            this.btnKendaraan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKendaraan.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnKendaraan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKendaraan.Click += new System.EventHandler(this.btnKendaraan_Click);
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(3, 149);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(211, 25);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "Selamat Datang Admin";
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "                   Tempat Wisata";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = true;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 247);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(235, 29);
            this.bunifuFlatButton1.TabIndex = 3;
            this.bunifuFlatButton1.Text = "                   Tempat Wisata";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // btnTourguide
            // 
            this.btnTourguide.Activecolor = System.Drawing.Color.IndianRed;
            this.btnTourguide.BackColor = System.Drawing.Color.Salmon;
            this.btnTourguide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTourguide.BorderRadius = 0;
            this.btnTourguide.ButtonText = "                   Tour Guide";
            this.btnTourguide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTourguide.DisabledColor = System.Drawing.Color.Gray;
            this.btnTourguide.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTourguide.Iconimage = null;
            this.btnTourguide.Iconimage_right = null;
            this.btnTourguide.Iconimage_right_Selected = null;
            this.btnTourguide.Iconimage_Selected = null;
            this.btnTourguide.IconMarginLeft = 0;
            this.btnTourguide.IconMarginRight = 0;
            this.btnTourguide.IconRightVisible = true;
            this.btnTourguide.IconRightZoom = 0D;
            this.btnTourguide.IconVisible = true;
            this.btnTourguide.IconZoom = 90D;
            this.btnTourguide.IsTab = true;
            this.btnTourguide.Location = new System.Drawing.Point(0, 282);
            this.btnTourguide.Name = "btnTourguide";
            this.btnTourguide.Normalcolor = System.Drawing.Color.Salmon;
            this.btnTourguide.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnTourguide.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnTourguide.selected = false;
            this.btnTourguide.Size = new System.Drawing.Size(235, 29);
            this.btnTourguide.TabIndex = 4;
            this.btnTourguide.Text = "                   Tour Guide";
            this.btnTourguide.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTourguide.Textcolor = System.Drawing.Color.White;
            this.btnTourguide.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTourguide.Click += new System.EventHandler(this.btnTourguide_Click);
            // 
            // btnDroppoint
            // 
            this.btnDroppoint.Activecolor = System.Drawing.Color.IndianRed;
            this.btnDroppoint.BackColor = System.Drawing.Color.Salmon;
            this.btnDroppoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDroppoint.BorderRadius = 0;
            this.btnDroppoint.ButtonText = "                   Drop Point";
            this.btnDroppoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDroppoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnDroppoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDroppoint.Iconimage = null;
            this.btnDroppoint.Iconimage_right = null;
            this.btnDroppoint.Iconimage_right_Selected = null;
            this.btnDroppoint.Iconimage_Selected = null;
            this.btnDroppoint.IconMarginLeft = 0;
            this.btnDroppoint.IconMarginRight = 0;
            this.btnDroppoint.IconRightVisible = true;
            this.btnDroppoint.IconRightZoom = 0D;
            this.btnDroppoint.IconVisible = true;
            this.btnDroppoint.IconZoom = 90D;
            this.btnDroppoint.IsTab = true;
            this.btnDroppoint.Location = new System.Drawing.Point(0, 212);
            this.btnDroppoint.Name = "btnDroppoint";
            this.btnDroppoint.Normalcolor = System.Drawing.Color.Salmon;
            this.btnDroppoint.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnDroppoint.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnDroppoint.selected = false;
            this.btnDroppoint.Size = new System.Drawing.Size(235, 29);
            this.btnDroppoint.TabIndex = 5;
            this.btnDroppoint.Text = "                   Drop Point";
            this.btnDroppoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDroppoint.Textcolor = System.Drawing.Color.White;
            this.btnDroppoint.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDroppoint.Click += new System.EventHandler(this.btnDroppoint_Click);
            // 
            // btnHotel
            // 
            this.btnHotel.Activecolor = System.Drawing.Color.IndianRed;
            this.btnHotel.BackColor = System.Drawing.Color.Salmon;
            this.btnHotel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHotel.BorderRadius = 0;
            this.btnHotel.ButtonText = "                    Hotel";
            this.btnHotel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHotel.DisabledColor = System.Drawing.Color.Gray;
            this.btnHotel.Iconcolor = System.Drawing.Color.Transparent;
            this.btnHotel.Iconimage = null;
            this.btnHotel.Iconimage_right = null;
            this.btnHotel.Iconimage_right_Selected = null;
            this.btnHotel.Iconimage_Selected = null;
            this.btnHotel.IconMarginLeft = 0;
            this.btnHotel.IconMarginRight = 0;
            this.btnHotel.IconRightVisible = true;
            this.btnHotel.IconRightZoom = 0D;
            this.btnHotel.IconVisible = true;
            this.btnHotel.IconZoom = 90D;
            this.btnHotel.IsTab = true;
            this.btnHotel.Location = new System.Drawing.Point(-3, 317);
            this.btnHotel.Name = "btnHotel";
            this.btnHotel.Normalcolor = System.Drawing.Color.Salmon;
            this.btnHotel.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnHotel.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnHotel.selected = false;
            this.btnHotel.Size = new System.Drawing.Size(235, 29);
            this.btnHotel.TabIndex = 6;
            this.btnHotel.Text = "                    Hotel";
            this.btnHotel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHotel.Textcolor = System.Drawing.Color.White;
            this.btnHotel.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHotel.Click += new System.EventHandler(this.btnHotel_Click);
            // 
            // btnMobil
            // 
            this.btnMobil.Activecolor = System.Drawing.Color.IndianRed;
            this.btnMobil.BackColor = System.Drawing.Color.Salmon;
            this.btnMobil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMobil.BorderRadius = 0;
            this.btnMobil.ButtonText = "                   Mobil";
            this.btnMobil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMobil.DisabledColor = System.Drawing.Color.Gray;
            this.btnMobil.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMobil.Iconimage = null;
            this.btnMobil.Iconimage_right = null;
            this.btnMobil.Iconimage_right_Selected = null;
            this.btnMobil.Iconimage_Selected = null;
            this.btnMobil.IconMarginLeft = 0;
            this.btnMobil.IconMarginRight = 0;
            this.btnMobil.IconRightVisible = true;
            this.btnMobil.IconRightZoom = 0D;
            this.btnMobil.IconVisible = true;
            this.btnMobil.IconZoom = 90D;
            this.btnMobil.IsTab = true;
            this.btnMobil.Location = new System.Drawing.Point(0, 352);
            this.btnMobil.Name = "btnMobil";
            this.btnMobil.Normalcolor = System.Drawing.Color.Salmon;
            this.btnMobil.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnMobil.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnMobil.selected = false;
            this.btnMobil.Size = new System.Drawing.Size(235, 29);
            this.btnMobil.TabIndex = 7;
            this.btnMobil.Text = "                   Mobil";
            this.btnMobil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMobil.Textcolor = System.Drawing.Color.White;
            this.btnMobil.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMobil.Click += new System.EventHandler(this.btnMobil_Click);
            // 
            // btnMember
            // 
            this.btnMember.Activecolor = System.Drawing.Color.IndianRed;
            this.btnMember.BackColor = System.Drawing.Color.Salmon;
            this.btnMember.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMember.BorderRadius = 0;
            this.btnMember.ButtonText = "                   Member";
            this.btnMember.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMember.DisabledColor = System.Drawing.Color.Gray;
            this.btnMember.Iconcolor = System.Drawing.Color.Transparent;
            this.btnMember.Iconimage = null;
            this.btnMember.Iconimage_right = null;
            this.btnMember.Iconimage_right_Selected = null;
            this.btnMember.Iconimage_Selected = null;
            this.btnMember.IconMarginLeft = 0;
            this.btnMember.IconMarginRight = 0;
            this.btnMember.IconRightVisible = true;
            this.btnMember.IconRightZoom = 0D;
            this.btnMember.IconVisible = true;
            this.btnMember.IconZoom = 90D;
            this.btnMember.IsTab = true;
            this.btnMember.Location = new System.Drawing.Point(0, 387);
            this.btnMember.Name = "btnMember";
            this.btnMember.Normalcolor = System.Drawing.Color.Salmon;
            this.btnMember.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnMember.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnMember.selected = false;
            this.btnMember.Size = new System.Drawing.Size(235, 29);
            this.btnMember.TabIndex = 8;
            this.btnMember.Text = "                   Member";
            this.btnMember.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMember.Textcolor = System.Drawing.Color.White;
            this.btnMember.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMember.Click += new System.EventHandler(this.btnMember_Click);
            // 
            // btnKaryawan
            // 
            this.btnKaryawan.Activecolor = System.Drawing.Color.IndianRed;
            this.btnKaryawan.BackColor = System.Drawing.Color.Salmon;
            this.btnKaryawan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKaryawan.BorderRadius = 0;
            this.btnKaryawan.ButtonText = "                   Karyawan";
            this.btnKaryawan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKaryawan.DisabledColor = System.Drawing.Color.Gray;
            this.btnKaryawan.Iconcolor = System.Drawing.Color.Transparent;
            this.btnKaryawan.Iconimage = null;
            this.btnKaryawan.Iconimage_right = null;
            this.btnKaryawan.Iconimage_right_Selected = null;
            this.btnKaryawan.Iconimage_Selected = null;
            this.btnKaryawan.IconMarginLeft = 0;
            this.btnKaryawan.IconMarginRight = 0;
            this.btnKaryawan.IconRightVisible = true;
            this.btnKaryawan.IconRightZoom = 0D;
            this.btnKaryawan.IconVisible = true;
            this.btnKaryawan.IconZoom = 90D;
            this.btnKaryawan.IsTab = true;
            this.btnKaryawan.Location = new System.Drawing.Point(0, 422);
            this.btnKaryawan.Name = "btnKaryawan";
            this.btnKaryawan.Normalcolor = System.Drawing.Color.Salmon;
            this.btnKaryawan.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnKaryawan.OnHoverTextColor = System.Drawing.Color.Maroon;
            this.btnKaryawan.selected = false;
            this.btnKaryawan.Size = new System.Drawing.Size(235, 29);
            this.btnKaryawan.TabIndex = 9;
            this.btnKaryawan.Text = "                   Karyawan";
            this.btnKaryawan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKaryawan.Textcolor = System.Drawing.Color.White;
            this.btnKaryawan.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKaryawan.Click += new System.EventHandler(this.btnKaryawan_Click);
            // 
            // PanelKiri
            // 
            this.PanelKiri.BackColor = System.Drawing.Color.Salmon;
            this.PanelKiri.Controls.Add(this.btnLogout);
            this.PanelKiri.Controls.Add(this.btnKaryawan);
            this.PanelKiri.Controls.Add(this.btnMember);
            this.PanelKiri.Controls.Add(this.btnMobil);
            this.PanelKiri.Controls.Add(this.btnHotel);
            this.PanelKiri.Controls.Add(this.btnDroppoint);
            this.PanelKiri.Controls.Add(this.btnTourguide);
            this.PanelKiri.Controls.Add(this.bunifuFlatButton1);
            this.PanelKiri.Controls.Add(this.bunifuCustomLabel2);
            this.PanelKiri.Controls.Add(this.btnKendaraan);
            this.PanelKiri.Controls.Add(this.pictureBox1);
            this.PanelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelKiri.Location = new System.Drawing.Point(0, 34);
            this.PanelKiri.Name = "PanelKiri";
            this.PanelKiri.Size = new System.Drawing.Size(235, 519);
            this.PanelKiri.TabIndex = 3;
            this.PanelKiri.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelKiri_Paint);
            // 
            // uiKaryawan1
            // 
            this.uiKaryawan1.BackColor = System.Drawing.Color.IndianRed;
            this.uiKaryawan1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiKaryawan1.Location = new System.Drawing.Point(235, 34);
            this.uiKaryawan1.Name = "uiKaryawan1";
            this.uiKaryawan1.Size = new System.Drawing.Size(883, 519);
            this.uiKaryawan1.TabIndex = 12;
            // 
            // uiMember1
            // 
            this.uiMember1.BackColor = System.Drawing.Color.IndianRed;
            this.uiMember1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiMember1.ForeColor = System.Drawing.Color.White;
            this.uiMember1.Location = new System.Drawing.Point(235, 34);
            this.uiMember1.Name = "uiMember1";
            this.uiMember1.Size = new System.Drawing.Size(883, 519);
            this.uiMember1.TabIndex = 11;
            // 
            // uiMobil1
            // 
            this.uiMobil1.BackColor = System.Drawing.Color.IndianRed;
            this.uiMobil1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiMobil1.Location = new System.Drawing.Point(235, 34);
            this.uiMobil1.Name = "uiMobil1";
            this.uiMobil1.Size = new System.Drawing.Size(883, 519);
            this.uiMobil1.TabIndex = 10;
            // 
            // uiHotel1
            // 
            this.uiHotel1.BackColor = System.Drawing.Color.IndianRed;
            this.uiHotel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiHotel1.Location = new System.Drawing.Point(235, 34);
            this.uiHotel1.Name = "uiHotel1";
            this.uiHotel1.Size = new System.Drawing.Size(883, 519);
            this.uiHotel1.TabIndex = 9;
            // 
            // uiTourguide1
            // 
            this.uiTourguide1.BackColor = System.Drawing.Color.IndianRed;
            this.uiTourguide1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTourguide1.Location = new System.Drawing.Point(235, 34);
            this.uiTourguide1.Name = "uiTourguide1";
            this.uiTourguide1.Size = new System.Drawing.Size(883, 519);
            this.uiTourguide1.TabIndex = 8;
            // 
            // uiDroppoint1
            // 
            this.uiDroppoint1.BackColor = System.Drawing.Color.IndianRed;
            this.uiDroppoint1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiDroppoint1.ForeColor = System.Drawing.Color.LightCoral;
            this.uiDroppoint1.Location = new System.Drawing.Point(235, 34);
            this.uiDroppoint1.Name = "uiDroppoint1";
            this.uiDroppoint1.Size = new System.Drawing.Size(883, 519);
            this.uiDroppoint1.TabIndex = 7;
            // 
            // uiTempatwisata1
            // 
            this.uiTempatwisata1.BackColor = System.Drawing.Color.IndianRed;
            this.uiTempatwisata1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTempatwisata1.Location = new System.Drawing.Point(235, 34);
            this.uiTempatwisata1.Name = "uiTempatwisata1";
            this.uiTempatwisata1.Size = new System.Drawing.Size(883, 519);
            this.uiTempatwisata1.TabIndex = 6;
            // 
            // uiKendaraan1
            // 
            this.uiKendaraan1.BackColor = System.Drawing.Color.IndianRed;
            this.uiKendaraan1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiKendaraan1.Location = new System.Drawing.Point(235, 34);
            this.uiKendaraan1.Name = "uiKendaraan1";
            this.uiKendaraan1.Size = new System.Drawing.Size(883, 519);
            this.uiKendaraan1.TabIndex = 5;
            // 
            // bunifuDragControl5
            // 
            this.bunifuDragControl5.Fixed = true;
            this.bunifuDragControl5.Horizontal = true;
            this.bunifuDragControl5.TargetControl = this.PanelAtas;
            this.bunifuDragControl5.Vertical = true;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Salmon;
            this.btnLogout.Image = ((System.Drawing.Image)(resources.GetObject("btnLogout.Image")));
            this.btnLogout.ImageActive = null;
            this.btnLogout.Location = new System.Drawing.Point(181, 472);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(51, 44);
            this.btnLogout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnLogout.TabIndex = 10;
            this.btnLogout.TabStop = false;
            this.btnLogout.Zoom = 10;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // UihomeAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(1118, 553);
            this.Controls.Add(this.uiKaryawan1);
            this.Controls.Add(this.uiMember1);
            this.Controls.Add(this.uiMobil1);
            this.Controls.Add(this.uiHotel1);
            this.Controls.Add(this.uiTourguide1);
            this.Controls.Add(this.uiDroppoint1);
            this.Controls.Add(this.uiTempatwisata1);
            this.Controls.Add(this.uiKendaraan1);
            this.Controls.Add(this.PanelKiri);
            this.Controls.Add(this.PanelAtas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UihomeAdmin";
            this.Text = "UihomeAdmin";
            this.Load += new System.EventHandler(this.UihomeAdmin_Load);
            this.PanelAtas.ResumeLayout(false);
            this.PanelAtas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelKiri.ResumeLayout(false);
            this.PanelKiri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogout)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel PanelAtas;
        private Bunifu.Framework.UI.BunifuImageButton btnclose2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private UiKendaraan uiKendaraan1;
        private System.Windows.Forms.Panel PanelKiri;
        private Bunifu.Framework.UI.BunifuFlatButton btnKaryawan;
        private Bunifu.Framework.UI.BunifuFlatButton btnMember;
        private Bunifu.Framework.UI.BunifuFlatButton btnMobil;
        private Bunifu.Framework.UI.BunifuFlatButton btnHotel;
        private Bunifu.Framework.UI.BunifuFlatButton btnDroppoint;
        private Bunifu.Framework.UI.BunifuFlatButton btnTourguide;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuFlatButton btnKendaraan;
        private System.Windows.Forms.PictureBox pictureBox1;
        private UiTempatwisata uiTempatwisata1;
        private UiDroppoint uiDroppoint1;
        private UiKaryawan uiKaryawan1;
        private UiMember uiMember1;
        private UiMobil uiMobil1;
        private UiHotel uiHotel1;
        private UiTourguide uiTourguide1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl5;
        private Bunifu.Framework.UI.BunifuImageButton btnLogout;
    }
}