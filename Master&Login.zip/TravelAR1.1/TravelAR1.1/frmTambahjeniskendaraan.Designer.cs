﻿namespace TravelAR1._1
{
    partial class frmTambahjeniskendaraan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTambahjeniskendaraan));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtJenis = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtKapasitas = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnSimpan = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnBersihkan = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnKembali = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(1, 32);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(370, 29);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Tambah Data Jenis Kendaraan";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Jenis";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kapasitas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(104, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = ":";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(104, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = ":";
            // 
            // txtJenis
            // 
            this.txtJenis.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJenis.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJenis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtJenis.HintForeColor = System.Drawing.Color.Empty;
            this.txtJenis.HintText = "";
            this.txtJenis.isPassword = false;
            this.txtJenis.LineFocusedColor = System.Drawing.Color.Maroon;
            this.txtJenis.LineIdleColor = System.Drawing.Color.White;
            this.txtJenis.LineMouseHoverColor = System.Drawing.Color.Maroon;
            this.txtJenis.LineThickness = 3;
            this.txtJenis.Location = new System.Drawing.Point(125, 103);
            this.txtJenis.Margin = new System.Windows.Forms.Padding(4);
            this.txtJenis.Name = "txtJenis";
            this.txtJenis.Size = new System.Drawing.Size(136, 27);
            this.txtJenis.TabIndex = 5;
            this.txtJenis.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtKapasitas
            // 
            this.txtKapasitas.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtKapasitas.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtKapasitas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtKapasitas.HintForeColor = System.Drawing.Color.Empty;
            this.txtKapasitas.HintText = "";
            this.txtKapasitas.isPassword = false;
            this.txtKapasitas.LineFocusedColor = System.Drawing.Color.Maroon;
            this.txtKapasitas.LineIdleColor = System.Drawing.Color.White;
            this.txtKapasitas.LineMouseHoverColor = System.Drawing.Color.Maroon;
            this.txtKapasitas.LineThickness = 3;
            this.txtKapasitas.Location = new System.Drawing.Point(125, 165);
            this.txtKapasitas.Margin = new System.Windows.Forms.Padding(4);
            this.txtKapasitas.Name = "txtKapasitas";
            this.txtKapasitas.Size = new System.Drawing.Size(136, 27);
            this.txtKapasitas.TabIndex = 6;
            this.txtKapasitas.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnSimpan
            // 
            this.btnSimpan.ActiveBorderThickness = 1;
            this.btnSimpan.ActiveCornerRadius = 20;
            this.btnSimpan.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSimpan.ActiveForecolor = System.Drawing.Color.White;
            this.btnSimpan.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSimpan.BackColor = System.Drawing.Color.IndianRed;
            this.btnSimpan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSimpan.BackgroundImage")));
            this.btnSimpan.ButtonText = "Simpan";
            this.btnSimpan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSimpan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimpan.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSimpan.IdleBorderThickness = 1;
            this.btnSimpan.IdleCornerRadius = 20;
            this.btnSimpan.IdleFillColor = System.Drawing.Color.IndianRed;
            this.btnSimpan.IdleForecolor = System.Drawing.Color.White;
            this.btnSimpan.IdleLineColor = System.Drawing.Color.Maroon;
            this.btnSimpan.Location = new System.Drawing.Point(6, 269);
            this.btnSimpan.Margin = new System.Windows.Forms.Padding(5);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(112, 39);
            this.btnSimpan.TabIndex = 7;
            this.btnSimpan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnBersihkan
            // 
            this.btnBersihkan.ActiveBorderThickness = 1;
            this.btnBersihkan.ActiveCornerRadius = 20;
            this.btnBersihkan.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnBersihkan.ActiveForecolor = System.Drawing.Color.White;
            this.btnBersihkan.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnBersihkan.BackColor = System.Drawing.Color.IndianRed;
            this.btnBersihkan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBersihkan.BackgroundImage")));
            this.btnBersihkan.ButtonText = "Bersihkan";
            this.btnBersihkan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBersihkan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBersihkan.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnBersihkan.IdleBorderThickness = 1;
            this.btnBersihkan.IdleCornerRadius = 20;
            this.btnBersihkan.IdleFillColor = System.Drawing.Color.IndianRed;
            this.btnBersihkan.IdleForecolor = System.Drawing.Color.White;
            this.btnBersihkan.IdleLineColor = System.Drawing.Color.Maroon;
            this.btnBersihkan.Location = new System.Drawing.Point(149, 269);
            this.btnBersihkan.Margin = new System.Windows.Forms.Padding(5);
            this.btnBersihkan.Name = "btnBersihkan";
            this.btnBersihkan.Size = new System.Drawing.Size(112, 39);
            this.btnBersihkan.TabIndex = 8;
            this.btnBersihkan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBersihkan.Click += new System.EventHandler(this.btnBersihkan_Click);
            // 
            // btnKembali
            // 
            this.btnKembali.ActiveBorderThickness = 1;
            this.btnKembali.ActiveCornerRadius = 20;
            this.btnKembali.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnKembali.ActiveForecolor = System.Drawing.Color.White;
            this.btnKembali.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnKembali.BackColor = System.Drawing.Color.IndianRed;
            this.btnKembali.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKembali.BackgroundImage")));
            this.btnKembali.ButtonText = "Kembali";
            this.btnKembali.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKembali.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKembali.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnKembali.IdleBorderThickness = 1;
            this.btnKembali.IdleCornerRadius = 20;
            this.btnKembali.IdleFillColor = System.Drawing.Color.IndianRed;
            this.btnKembali.IdleForecolor = System.Drawing.Color.White;
            this.btnKembali.IdleLineColor = System.Drawing.Color.Maroon;
            this.btnKembali.Location = new System.Drawing.Point(247, 348);
            this.btnKembali.Margin = new System.Windows.Forms.Padding(5);
            this.btnKembali.Name = "btnKembali";
            this.btnKembali.Size = new System.Drawing.Size(112, 39);
            this.btnKembali.TabIndex = 9;
            this.btnKembali.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnKembali.Click += new System.EventHandler(this.btnKembali_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // frmTambahjeniskendaraan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(373, 413);
            this.Controls.Add(this.btnKembali);
            this.Controls.Add(this.btnBersihkan);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.txtKapasitas);
            this.Controls.Add(this.txtJenis);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTambahjeniskendaraan";
            this.Text = "frmTambahjeniskendaraan";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnKembali;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBersihkan;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSimpan;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtKapasitas;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJenis;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
    }
}