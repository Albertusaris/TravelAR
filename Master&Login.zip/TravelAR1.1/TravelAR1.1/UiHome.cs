﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelAR1._1
{
    public partial class UiHome : UserControl
    {
        public UiHome()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if(txtUsername.Text == "admin" && txtPassword.Text == "admin" )
            {
                UihomeAdmin admin = new UihomeAdmin();
                admin.Show();
                //UiHome home = new UiHome();
                //home.Show();
                Form1 form = new Form1();
                form.Hide();
            }
            else
            {
                MessageBox.Show("Username dan Password Salah");
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

        }
    }
}
