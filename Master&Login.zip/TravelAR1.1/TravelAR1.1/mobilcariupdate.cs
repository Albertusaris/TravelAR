﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TravelAR1._1
{
    public partial class mobilcariupdate : UserControl
    {
        public mobilcariupdate()
        {
            InitializeComponent();
        }
        private void clear()
        {
            txtIdmobil.Text = "";
            txtJenis.Text = "";
            txtPenumpang.Text = "";
            txtJmlmobil.Text = "";
            txtHarga.Text = "";
        }

        private void mobilcariupdate_Load(object sender, EventArgs e)
        {
            Datagrid();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatmobil", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtIdmobil.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtJenis.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtPenumpang.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtJmlmobil.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtHarga.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtIdmobil.Text == "" || txtJenis.Text == "" || txtPenumpang.Text == "" || txtJmlmobil.Text == "" || txtHarga.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatemobil", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@harga", txtHarga.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@id_mobil", txtIdmobil.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@jml_mobil", txtJmlmobil.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil DiUpdate!");
                clear();
            }
                
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtIdmobil.Text == "" || txtJenis.Text == "" || txtPenumpang.Text == "" || txtJmlmobil.Text == "" || txtHarga.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletemobil", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id_mobil", txtIdmobil.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    clear();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
                
        }

        private void txtJmlmobil_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtHarga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
