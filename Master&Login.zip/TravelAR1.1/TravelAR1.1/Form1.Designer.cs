﻿namespace TravelAR1._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.PanelKiri = new System.Windows.Forms.Panel();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTktBus = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PanelAtas = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.btnMember = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnStaff = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnCs = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnManager = new Bunifu.Framework.UI.BunifuImageButton();
            this.uiHome1 = new TravelAR1._1.UiHome();
            this.uilogincs1 = new TravelAR1._1.Uilogincs();
            this.uiloginmanager1 = new TravelAR1._1.Uiloginmanager();
            this.uiloginadm1 = new TravelAR1._1.Uiloginadm();
            this.bunifuDragControl3 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.PanelKiri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelAtas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMember)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnStaff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnManager)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // PanelKiri
            // 
            this.PanelKiri.BackColor = System.Drawing.Color.Salmon;
            this.PanelKiri.Controls.Add(this.bunifuFlatButton3);
            this.PanelKiri.Controls.Add(this.bunifuFlatButton2);
            this.PanelKiri.Controls.Add(this.bunifuFlatButton1);
            this.PanelKiri.Controls.Add(this.btnTktBus);
            this.PanelKiri.Controls.Add(this.pictureBox1);
            this.PanelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelKiri.Location = new System.Drawing.Point(0, 34);
            this.PanelKiri.Name = "PanelKiri";
            this.PanelKiri.Size = new System.Drawing.Size(235, 519);
            this.PanelKiri.TabIndex = 0;
            this.PanelKiri.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelKiri_Paint);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "Penyewaan Mobil";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = true;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(0, 372);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(235, 48);
            this.bunifuFlatButton3.TabIndex = 4;
            this.bunifuFlatButton3.Text = "Penyewaan Mobil";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Pemesanan Hotel";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = true;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(0, 304);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(235, 48);
            this.bunifuFlatButton2.TabIndex = 3;
            this.bunifuFlatButton2.Text = "Pemesanan Hotel";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.IndianRed;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Pembelian Tiket Wisata";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = true;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 240);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.Salmon;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(235, 48);
            this.bunifuFlatButton1.TabIndex = 2;
            this.bunifuFlatButton1.Text = "Pembelian Tiket Wisata";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnTktBus
            // 
            this.btnTktBus.Activecolor = System.Drawing.Color.IndianRed;
            this.btnTktBus.BackColor = System.Drawing.Color.Salmon;
            this.btnTktBus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTktBus.BorderRadius = 0;
            this.btnTktBus.ButtonText = "Pembelian Tiket Bus";
            this.btnTktBus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTktBus.DisabledColor = System.Drawing.Color.Gray;
            this.btnTktBus.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTktBus.Iconimage = null;
            this.btnTktBus.Iconimage_right = null;
            this.btnTktBus.Iconimage_right_Selected = null;
            this.btnTktBus.Iconimage_Selected = null;
            this.btnTktBus.IconMarginLeft = 0;
            this.btnTktBus.IconMarginRight = 0;
            this.btnTktBus.IconRightVisible = true;
            this.btnTktBus.IconRightZoom = 0D;
            this.btnTktBus.IconVisible = true;
            this.btnTktBus.IconZoom = 90D;
            this.btnTktBus.IsTab = true;
            this.btnTktBus.Location = new System.Drawing.Point(0, 177);
            this.btnTktBus.Name = "btnTktBus";
            this.btnTktBus.Normalcolor = System.Drawing.Color.Salmon;
            this.btnTktBus.OnHovercolor = System.Drawing.Color.Salmon;
            this.btnTktBus.OnHoverTextColor = System.Drawing.Color.White;
            this.btnTktBus.selected = false;
            this.btnTktBus.Size = new System.Drawing.Size(235, 48);
            this.btnTktBus.TabIndex = 1;
            this.btnTktBus.Text = "Pembelian Tiket Bus";
            this.btnTktBus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTktBus.Textcolor = System.Drawing.Color.White;
            this.btnTktBus.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 129);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // PanelAtas
            // 
            this.PanelAtas.BackColor = System.Drawing.Color.LightCoral;
            this.PanelAtas.Controls.Add(this.bunifuImageButton1);
            this.PanelAtas.Controls.Add(this.bunifuCustomLabel1);
            this.PanelAtas.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelAtas.Location = new System.Drawing.Point(0, 0);
            this.PanelAtas.Name = "PanelAtas";
            this.PanelAtas.Size = new System.Drawing.Size(1118, 34);
            this.PanelAtas.TabIndex = 1;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.LightCoral;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1063, 3);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(38, 36);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 1;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(233, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sistem Informasi - TravelAR";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.PanelAtas;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.PanelAtas;
            this.bunifuDragControl2.Vertical = true;
            // 
            // btnMember
            // 
            this.btnMember.BackColor = System.Drawing.Color.IndianRed;
            this.btnMember.Image = ((System.Drawing.Image)(resources.GetObject("btnMember.Image")));
            this.btnMember.ImageActive = null;
            this.btnMember.Location = new System.Drawing.Point(736, 37);
            this.btnMember.Name = "btnMember";
            this.btnMember.Size = new System.Drawing.Size(82, 60);
            this.btnMember.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMember.TabIndex = 5;
            this.btnMember.TabStop = false;
            this.btnMember.Zoom = 10;
            this.btnMember.Click += new System.EventHandler(this.bunifuImageButton2_Click);
            // 
            // btnStaff
            // 
            this.btnStaff.BackColor = System.Drawing.Color.IndianRed;
            this.btnStaff.Image = ((System.Drawing.Image)(resources.GetObject("btnStaff.Image")));
            this.btnStaff.ImageActive = null;
            this.btnStaff.Location = new System.Drawing.Point(824, 37);
            this.btnStaff.Name = "btnStaff";
            this.btnStaff.Size = new System.Drawing.Size(82, 60);
            this.btnStaff.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnStaff.TabIndex = 6;
            this.btnStaff.TabStop = false;
            this.btnStaff.Zoom = 10;
            this.btnStaff.Click += new System.EventHandler(this.btnStaff_Click);
            // 
            // btnCs
            // 
            this.btnCs.BackColor = System.Drawing.Color.IndianRed;
            this.btnCs.Image = ((System.Drawing.Image)(resources.GetObject("btnCs.Image")));
            this.btnCs.ImageActive = null;
            this.btnCs.Location = new System.Drawing.Point(912, 37);
            this.btnCs.Name = "btnCs";
            this.btnCs.Size = new System.Drawing.Size(82, 60);
            this.btnCs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnCs.TabIndex = 7;
            this.btnCs.TabStop = false;
            this.btnCs.Zoom = 10;
            this.btnCs.Click += new System.EventHandler(this.btnCs_Click);
            // 
            // btnManager
            // 
            this.btnManager.BackColor = System.Drawing.Color.IndianRed;
            this.btnManager.Image = ((System.Drawing.Image)(resources.GetObject("btnManager.Image")));
            this.btnManager.ImageActive = null;
            this.btnManager.Location = new System.Drawing.Point(1000, 37);
            this.btnManager.Name = "btnManager";
            this.btnManager.Size = new System.Drawing.Size(82, 60);
            this.btnManager.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnManager.TabIndex = 8;
            this.btnManager.TabStop = false;
            this.btnManager.Zoom = 10;
            this.btnManager.Click += new System.EventHandler(this.btnManager_Click);
            // 
            // uiHome1
            // 
            this.uiHome1.BackColor = System.Drawing.Color.IndianRed;
            this.uiHome1.Location = new System.Drawing.Point(235, 95);
            this.uiHome1.Name = "uiHome1";
            this.uiHome1.Size = new System.Drawing.Size(883, 458);
            this.uiHome1.TabIndex = 2;
            this.uiHome1.Load += new System.EventHandler(this.uiHome1_Load);
            // 
            // uilogincs1
            // 
            this.uilogincs1.BackColor = System.Drawing.Color.IndianRed;
            this.uilogincs1.Location = new System.Drawing.Point(235, 103);
            this.uilogincs1.Name = "uilogincs1";
            this.uilogincs1.Size = new System.Drawing.Size(883, 450);
            this.uilogincs1.TabIndex = 9;
            // 
            // uiloginmanager1
            // 
            this.uiloginmanager1.BackColor = System.Drawing.Color.IndianRed;
            this.uiloginmanager1.Location = new System.Drawing.Point(235, 103);
            this.uiloginmanager1.Name = "uiloginmanager1";
            this.uiloginmanager1.Size = new System.Drawing.Size(883, 447);
            this.uiloginmanager1.TabIndex = 10;
            // 
            // uiloginadm1
            // 
            this.uiloginadm1.BackColor = System.Drawing.Color.IndianRed;
            this.uiloginadm1.Location = new System.Drawing.Point(235, 103);
            this.uiloginadm1.Name = "uiloginadm1";
            this.uiloginadm1.Size = new System.Drawing.Size(883, 450);
            this.uiloginadm1.TabIndex = 11;
            // 
            // bunifuDragControl3
            // 
            this.bunifuDragControl3.Fixed = true;
            this.bunifuDragControl3.Horizontal = true;
            this.bunifuDragControl3.TargetControl = this.PanelAtas;
            this.bunifuDragControl3.Vertical = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(1118, 553);
            this.Controls.Add(this.uiloginadm1);
            this.Controls.Add(this.uiloginmanager1);
            this.Controls.Add(this.uilogincs1);
            this.Controls.Add(this.btnManager);
            this.Controls.Add(this.btnCs);
            this.Controls.Add(this.btnStaff);
            this.Controls.Add(this.btnMember);
            this.Controls.Add(this.uiHome1);
            this.Controls.Add(this.PanelKiri);
            this.Controls.Add(this.PanelAtas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PanelKiri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelAtas.ResumeLayout(false);
            this.PanelAtas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMember)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnStaff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnManager)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel PanelKiri;
        private Bunifu.Framework.UI.BunifuFlatButton btnTktBus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel PanelAtas;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private UiHome uiHome1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuImageButton btnStaff;
        private Bunifu.Framework.UI.BunifuImageButton btnMember;
        private Bunifu.Framework.UI.BunifuImageButton btnManager;
        private Bunifu.Framework.UI.BunifuImageButton btnCs;
        private Uiloginmanager uiloginmanager1;
        private Uilogincs uilogincs1;
        private Uiloginadm uiloginadm1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl3;
    }
}

