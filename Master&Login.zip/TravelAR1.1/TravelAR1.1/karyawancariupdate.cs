﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace TravelAR1._1
{
    public partial class karyawancariupdate : UserControl
    {
        public karyawancariupdate()
        {
            InitializeComponent();
        }

        private void karyawancariupdate_Load(object sender, EventArgs e)
        {
            Datagrid();
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihatkaryawan", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtIdKaryawan.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtNama.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtNik.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtEmail.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtNotelp.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtJabatan.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtUsername.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtPass.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtNama.Text == "" || txtNik.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "" || txtUsername.Text == "" || txtPass.Text == "")
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                connection.Open();
                SqlCommand sqlcmd = new SqlCommand("sp_updatekaryawan", connection);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@no_telp", txtNotelp.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@password", txtPass.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@id_karyawan", txtIdKaryawan.Text.Trim());
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil DiUpdate!");
                clear();
            }
                
        }
        private void clear()
        {
            txtIdKaryawan.Text = "";
            txtNama.Text = "";
            txtNik.Text = "";
            txtEmail.Text = "";
            txtNotelp.Text = "";
            txtUsername.Text = "";
            txtPass.Text = "";
            txtJabatan.Text = "";
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
       
                try
                {
                    SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
                    connection.Open();
                    SqlCommand sqlcmd = new SqlCommand("sp_deletekaryawan", connection);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id_karyawan", txtIdKaryawan.Text.Trim());
                    sqlcmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil DiHapus!");
                    clear();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            
               
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void txtNotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            //setting format regular expression
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            //Regex regex = new Regex(regexPattern);
            if (Regex.IsMatch(txtEmail.Text, regexPattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.txtEmail, "Format Tidak Sesuai");
                return;
            }
        }
    }
}
