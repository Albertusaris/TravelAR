﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace TravelAR1._1
{
    public partial class UiTourguide : UserControl
    {
        public UiTourguide()
        {
            InitializeComponent();
            string query = "select top 1 id_tourguide from ms_tourguide order by id_tourguide desc";
            txtIdtourguide.Text = autogenerateID("TG", query);
        }
        SqlCommand sqlCmd;
        SqlConnection sqlCon;
        static string connectionString = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
        public string autogenerateID(string firstText, string query)
        {
            string result = "";
            int num = 0;
            try
            {
                sqlCon = new SqlConnection(connectionString);
                sqlCon.Open();
                sqlCmd = new SqlCommand(query, sqlCon);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    string last = reader[0].ToString();
                    num = Convert.ToInt32(last.Remove(0, firstText.Length)) + 1;
                }
                else
                {
                    num = 1;
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            result = firstText + num.ToString().PadLeft(2, '0');
            return result;
        }

        private void UiTourguide_Load(object sender, EventArgs e)
        {
            Datagrid();
            Tampilcmbkota();
            tourguidecariupdate1.Hide();
            btnKembali.Hide();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (cmbKota.Text == "" || txtnama.Text == "" || txtEmail.Text == "" || txtNotelp.Text == "" )
            {
                MessageBox.Show("Data tidak boleh kosong");
            }
            else
            {
                string connectionstring = "integrated security=true;data source=DESKTOP-QVO3FSO\\SQLEXPRESS;initial catalog=TravelAR";
                SqlConnection connection = new SqlConnection(connectionstring);

                SqlCommand insert = new SqlCommand("sp_inputtourguide", connection);
                insert.CommandType = CommandType.StoredProcedure;

                insert.Parameters.AddWithValue("id_tourguide", txtIdtourguide.Text);
                insert.Parameters.AddWithValue("kota", cmbKota.Text);
                insert.Parameters.AddWithValue("nama", txtnama.Text);
                insert.Parameters.AddWithValue("email", txtEmail.Text);
                insert.Parameters.AddWithValue("no_telp", txtNotelp.Text);

                try
                {
                    connection.Open();
                    insert.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil Tersimpan", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data Belum Tersimpan " + ex.Message);

                }
            }
                
        }
        public void Datagrid()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            connection.Open();
            SqlCommand mycmd = new SqlCommand("sp_lihattourguide", connection);
            mycmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mycmd.ExecuteReader());
            dataGridView1.DataSource = dt;
        }
        private void Tampilcmbkota()
        {
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-QVO3FSO\\SQLEXPRESS;Initial Catalog=TravelAR;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DISTINCT asal FROM tb_tempat", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbKota.Items.Clear();
            foreach (DataRow ROW in dt.Rows)
            {
                cmbKota.Items.Add(ROW["asal"].ToString());
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtIdtourguide.Text = "";
            txtnama.Text = "";
            txtEmail.Text = "";
            txtNotelp.Text = "";
            cmbKota.Text = "";
            string query = "select top 1 id_tourguide from ms_tourguide order by id_tourguide desc";
            txtIdtourguide.Text = autogenerateID("TG", query);

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Datagrid();
        }

        private void btnKembali_Click(object sender, EventArgs e)
        {
            tourguidecariupdate1.Hide();
            btnKembali.Hide();
        }

        private void btnHapus2_Click(object sender, EventArgs e)
        {
            tourguidecariupdate1.Show();
            btnKembali.Show();
        }

        private void txtNotelp_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            
        }
       

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
        
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            //setting format regular expression
            string regexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            //Regex regex = new Regex(regexPattern);
            if (Regex.IsMatch(txtEmail.Text, regexPattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.txtEmail, "Format Tidak Sesuai");
                return;
            }
        }

        private void txtnama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
        }
    }
}
